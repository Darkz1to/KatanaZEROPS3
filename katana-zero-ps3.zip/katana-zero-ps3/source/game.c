/* Port em C do clone Java de Katana ZERO (game.mvc.*).
 * A logica foi mantida o mais fiel possivel ao original; o mundo continua
 * em "unidades de 1080p" (bloco = 72) e e desenhado a metade da escala no
 * buffer 640x360 (os sprites do original eram ampliados 2x). */
#include "game.h"
#include "gfx.h"
#include "audio.h"
#include "gen_assets.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define BLOCK 72
#define MIN_RADIUS 36
#define DIMW 1280              /* area visivel em unidades de mundo (640*2) */
#define DIMH 720
#define ATTACK_FRAMES 6        /* valor efetivo do 'attackFrames' estatico do Java */
#define POOL 6000

GameState G;
Ent *zero = NULL;

static Ent zero_ent;
static Ent pool[POOL];
static Ent *freelist[POOL];
static int nfree = 0;
static char dir_data[256];

/* ---- aleatorio ---------------------------------------------------------- */
static uint32_t rng = 0x1234567u;
static int rnd(int n)
{
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    return (int)((rng >> 8) % (uint32_t)n);
}

/* ---- listas ---------------------------------------------------------------- */
typedef struct { Ent **a; int n, cap; } List;
static Ent *l_floor[2048], *l_friend[4], *l_enemy[1024], *l_back[64], *l_blood[2048],
           *l_katana[16], *l_punch[64], *l_bullet[256], *l_debris[256];
static List floors = {l_floor, 0, 2048}, friends = {l_friend, 0, 4}, enemies = {l_enemy, 0, 1024},
            backg = {l_back, 0, 64}, bloods = {l_blood, 0, 2048}, katanas = {l_katana, 0, 16},
            punches = {l_punch, 0, 64}, bullets = {l_bullet, 0, 256}, debris = {l_debris, 0, 256};

static void l_add(List *l, Ent *e) { if (l->n < l->cap) l->a[l->n++] = e; }
static int l_remove(List *l, Ent *e)
{
    for (int i = 0; i < l->n; i++)
        if (l->a[i] == e) {
            memmove(&l->a[i], &l->a[i + 1], (size_t)(l->n - i - 1) * sizeof(Ent *));
            l->n--;
            return 1;
        }
    return 0;
}

typedef struct { Ent *e; int add; } Op;
static Op ops[4096];
static int nops = 0;
static void enqueue(Ent *e, int add) { if (e && nops < 4096) { ops[nops].e = e; ops[nops].add = add; nops++; } }

static Ent *ent_new(int type, int team)
{
    if (nfree == 0) return NULL;
    Ent *e = freelist[--nfree];
    memset(e, 0, sizeof(*e));
    e->used = 1; e->type = type; e->team = team;
    return e;
}
static void ent_free(Ent *e)
{
    if (!e || e == &zero_ent || !e->used) return;
    e->used = 0;
    freelist[nfree++] = e;
}

static void process_ops(void)
{
    for (int i = 0; i < nops; i++) {
        Ent *e = ops[i].e;
        int add = ops[i].add;
        List *l = NULL; List *l2 = NULL;
        switch (e->team) {
        case TEAM_FLOOR: l = &floors; break;
        case TEAM_FRIEND: l = &friends; break;
        case TEAM_ENEMY: l = &enemies; break;
        case TEAM_BACKGROUND: l = &backg; l2 = &bloods; break;  /* sem break no Java: portas vao nas duas */
        case TEAM_BLOOD: l = &bloods; break;
        case TEAM_KATANA: l = &katanas; break;
        case TEAM_PUNCH: l = &punches; break;
        case TEAM_BULLET: l = &bullets; break;
        case TEAM_DEBRIS: l = &debris; break;
        }
        if (!l) continue;
        if (add) {
            if (e->used) { l_add(l, e); if (l2) l_add(l2, e); }
        } else {
            int r = l_remove(l, e);
            if (l2) r |= l_remove(l2, e);
            if (r) ent_free(e);
        }
    }
    nops = 0;
}

/* ---- geometria / colisao ---------------------------------------------------- */
static void set_cx(Ent *e, int x) { e->cx = x; if (e->hasbb) e->bb.x = x - e->bb.w / 2; }
static void set_cy(Ent *e, int y) { e->cy = y; if (e->hasbb) e->bb.y = y - e->bb.h / 2; }
static double dist(const Ent *a, const Ent *b)
{
    double dx = a->cx - b->cx, dy = a->cy - b->cy;
    return sqrt(dx * dx + dy * dy);
}

static Ent *find_wall(Ent *e)
{
    for (int i = 0; i < floors.n; i++) {
        const Rect *r = &floors.a[i]->bb;
        int noX = e->bb.x + e->bb.w <= r->x || e->bb.x >= r->x + r->w;
        int noY = e->bb.y + e->bb.h <= r->y || e->bb.y >= r->y + r->h;
        if (!noX && !noY) return floors.a[i];
    }
    return NULL;
}
static int on_left_wall(Ent *e)  { set_cx(e, e->cx - 2); Ent *b = find_wall(e); set_cx(e, e->cx + 2); return b != NULL; }
static int on_right_wall(Ent *e) { set_cx(e, e->cx + 2); Ent *b = find_wall(e); set_cx(e, e->cx - 2); return b != NULL; }
static int on_platform(Ent *e)   { set_cy(e, e->cy + 2); Ent *b = find_wall(e); set_cy(e, e->cy - 2); return b != NULL; }

/* Character.move */
static void char_move(Ent *e)
{
    set_cy(e, (int)(e->cy + e->dy));
    Ent *b = find_wall(e);
    if (b) {
        if (e->dy > 0) {
            set_cy(e, b->bb.y - e->bb.h / 2);
            e->yVelocity = 0;
            sfx_play("zero/player_land");
        } else if (e->dy < 0) {
            set_cy(e, b->bb.y + b->bb.h + e->bb.h / 2);
            e->yVelocity = 0;
        }
        e->dy = 0;
    }
    set_cx(e, (int)(e->cx + e->dx));
    b = find_wall(e);
    if (b) {
        if (e->dx > 0) { set_cx(e, b->bb.x - e->bb.w / 2); e->xVelocity = 0; }
        else if (e->dx < 0) { set_cx(e, b->bb.x + b->bb.w + e->bb.w / 2); e->xVelocity = 0; }
        e->dx = 0;
    }
    e->bb.x = e->cx - e->bb.w / 2;
    e->bb.y = e->cy - e->bb.h / 2;
}

/* Sprite.move */
static void sprite_expire(Ent *e)
{
    if (e->expiry == 1) enqueue(e, 0);
    e->expiry--;
}
static void sprite_move(Ent *e)
{
    if (e->alias) { e->cx = e->alias->cx; e->cy = e->alias->cy; e->alias = NULL; }
    e->cx = (int)(e->cx + e->dx);
    e->cy = (int)(e->cy + e->dy);
    if (e->expiry > 0) sprite_expire(e);
    if (e->hasbb) { e->bb.x = e->cx - e->bb.w / 2; e->bb.y = e->cy - e->bb.h / 2; }
}

/* ---- desenho helpers -------------------------------------------------------- */
/* centro dado em unidades de mundo ja relativas a camera; imagem desenhada a 2x
 * no original = 1x aqui */
static void draw_at(const Img *im, int wx, int wy, int flip)
{
    int x = (wx - im->w) >> 1, y = (wy - im->h) >> 1;
    if (flip) gfx_blit_flip(im, x, y); else gfx_blit(im, x, y);
}
static void draw_at_rot(const Img *im, const Ent *e, int flip)
{
    gfx_blit_rot(im, (e->cx - G.viewX) * 0.5, (e->cy - G.viewY) * 0.5, e->orientation, flip);
}
/* renderRasterFromRect / FlipFromRect */
static void draw_rect(const Img *im, const Ent *e, int offX, int offY, int flip)
{
    int cxw = e->bb.x + e->bb.w / 2, cyw = e->bb.y + e->bb.h / 2;
    if (flip) draw_at(im, cxw - G.viewX - offX, cyw - G.viewY + offY, 1);
    else      draw_at(im, cxw - G.viewX + offX, cyw - G.viewY + offY, 0);
}

/* ---- criacao de entidades ---------------------------------------------------- */
static void char_defaults(Ent *e)
{
    e->viewRadius = 300; e->attackRadius = 36;
    e->totalPreAttackFrames = 5; e->totalAttackIntervalFrames = 15;
    e->xAccelerate = 1.4; e->xSlowdownAccelerate = 10;
    e->maxXVelocity = 18; e->maxYVelocity = 30;
    e->radius = MIN_RADIUS;
    e->hasbb = 1;
    e->bb.w = e->bb.h = BLOCK;
}

static void zero_reset(int cx, int cy)
{
    memset(&zero_ent, 0, sizeof(zero_ent));
    zero_ent.used = 1; zero_ent.type = T_ZERO; zero_ent.team = TEAM_FRIEND;
    char_defaults(&zero_ent);
    zero_ent.hurtGroundFrames = 6;
    set_cx(&zero_ent, cx); set_cy(&zero_ent, cy);
    zero = &zero_ent;
}

static Ent *new_enemy(int type, int cx, int cy)
{
    Ent *e = ent_new(type, TEAM_ENEMY);
    if (!e) return NULL;
    char_defaults(e);
    e->action = ACT_IDLE;
    switch (type) {
    case T_GRUNT: e->hurtGroundFrames = 16; e->maxXVelocity = 15; break;
    case T_POMP:  e->attackRadius = 40; e->hurtGroundFrames = 15; e->maxXVelocity = 15; break;
    case T_GANG:  e->hurtGroundFrames = 14; e->maxXVelocity = 15; e->attackRadius = 300;
                  e->totalPreAttackFrames = 10; break;
    case T_SHLD:  e->hurtGroundFrames = 15; e->viewRadius = 600; e->attackRadius = 500;
                  e->totalPreAttackFrames = 10; break;
    }
    set_cx(e, cx); set_cy(e, cy);
    enqueue(e, 1);
    G.enemyNums++;
    return e;
}

static int splat_dir(double theta)
{
    double d = theta * 180.0 / 3.14159265358979323846;
    if (d <= 0 && d > -22.5) return 0;
    if (d <= -22.5 && d > -45) return 1;
    if (d <= -45 && d > -67.5) return 2;
    if (d <= -67.5 && d > -90) return 3;
    if (d <= -90 && d > -112.5) return 4;
    if (d <= -112.5 && d > -135) return 5;
    if (d <= -135 && d > -157.5) return 6;
    if (d <= -157.5 && d > -180) return 7;
    if (d <= 180 && d > 157.5) return 8;
    if (d <= 157.5 && d > 135) return 9;
    if (d <= 135 && d > 112.5) return 10;
    if (d <= 112.5 && d > 90) return 11;
    if (d <= 90 && d > 67.5) return 12;
    if (d <= 67.5 && d > 45) return 13;
    if (d <= 45 && d > 22.5) return 14;
    return 15;
}

static void add_blood(double theta, Ent *owner)
{
    if (bloods.n > 1500) return;
    Ent *e = ent_new(T_BLOOD, TEAM_BLOOD);
    if (!e) return;
    e->theta = theta; e->alias = owner; e->cx = owner->cx; e->cy = owner->cy;
    e->isSplatter = 1;
    e->bgBloodIdx = rnd(9);
    e->bgBloodLeft = rnd(2) == 0;
    e->orientation = rnd(360);
    int s0 = splat_dir(theta);
    e->sp[0] = s0; e->sp[1] = (s0 + 15) % 16; e->sp[2] = (s0 + 1) % 16;
    e->sp[3] = rnd(16); e->sp[4] = rnd(16); e->sp[5] = rnd(16);
    enqueue(e, 1);
}

static void add_debris(int type, int expiry, Ent *owner, int cx, int cy, int orient)
{
    Ent *e = ent_new(type, TEAM_DEBRIS);
    if (!e) return;
    e->expiry = expiry; e->alias = owner; e->cx = cx; e->cy = cy; e->orientation = orient;
    enqueue(e, 1);
}

/* ---- inimigos ---------------------------------------------------------------- */
static void set_chasing(Ent *e, int st)
{
    e->isChasing = st;
    if (!e->isProtected && !e->isAttack) e->action = st ? ACT_RUN : ACT_IDLE;
}

static void enemy_hurt(Ent *e, Ent *obj)
{
    e->dx = (e->cx - obj->cx) * 2;
    e->dy = e->cy - obj->cy;
    e->action = ACT_HURT;
    e->isProtected = 1;
    e->isHurtGround = 1;
    e->yVelocity = 0;
    set_chasing(e, 0);
    if (e->punch) { enqueue(e->punch, 0); e->punch = NULL; }   /* corrige "soco fantasma" do original */
    add_blood(obj->theta, e);
}

static void enemy_attack(Ent *e)
{
    if (!e->canAttack) return;
    int gun = (e->type == T_GANG || e->type == T_SHLD);
    if (e->currentPreAttackFrame < e->totalPreAttackFrames) {
        if (G.frame % 2 == 0) e->currentPreAttackFrame++;
    } else if (e->currentAttackIntervalFrame == 0) {
        e->currentPreAttackFrame = 0;
        e->currentAttackIntervalFrame = e->totalAttackIntervalFrames;
        if (!gun) {
            Ent *p = ent_new(T_PUNCH, TEAM_PUNCH);
            e->isAttack = 1;
            e->action = ACT_ATTACK;
            if (p) {
                p->radius = 36; p->alias = e; p->cx = e->cx; p->cy = e->cy;
                e->punch = p;
                enqueue(p, 1);
            }
            sfx_play("enemy/punch");
        } else {
            int n = (e->type == T_SHLD) ? 3 : 1;
            for (int i = 0; i < n; i++) {
                Ent *b = ent_new(T_BULLET, TEAM_BULLET);
                if (!b) break;
                b->radius = 16;
                b->bvx = e->atLeft ? -50 : 50;
                b->bvy = rnd(7) - 3;
                b->alias = e; b->cx = e->cx; b->cy = e->cy;
                enqueue(b, 1);
            }
            sfx_play("bullet/gun_fire");
            sfx_play("bullet/sound_enemy_shotgun_reload_01");
        }
    } else if (G.frame % 2 == 0) {
        e->currentAttackIntervalFrame--;
    }
}

static void enemy_move(Ent *e)
{
    char_move(e);
    if (!e->isAttack) {
        if (e->isChasing) {
            if (fabs(e->xVelocity) < e->maxXVelocity)
                e->xVelocity += e->atLeft ? -e->xAccelerate : e->xAccelerate;
            if (e->atLeft && e->xVelocity > 0) e->xVelocity = -e->xVelocity;
            if (!e->atLeft && e->xVelocity < 0) e->xVelocity = -e->xVelocity;
        } else if (e->xVelocity != 0) {
            if (e->xVelocity > 0)
                e->xVelocity = e->xVelocity > e->xSlowdownAccelerate ? e->xVelocity - e->xSlowdownAccelerate : 0;
            else
                e->xVelocity = fabs(e->xVelocity) > e->xSlowdownAccelerate ? e->xVelocity + e->xSlowdownAccelerate : 0;
        }
        if (!on_platform(e)) {
            if (fabs(e->yVelocity) <= e->maxYVelocity) e->yVelocity -= -1.6;
        }
        e->dx = e->xVelocity;
        e->dy = e->yVelocity;
    }
}

static void enemy_draw(Ent *e)
{
    int sidle, shurt, swalk, srun, sattack;
    int offX = 0, offY = 0;
    switch (e->type) {
    case T_GRUNT: sidle = SET_GRUNT_IDLE; shurt = SET_GRUNT_HURT; swalk = SET_GRUNT_WALK; srun = SET_GRUNT_RUN; sattack = SET_GRUNT_ATTACK; break;
    case T_POMP:  sidle = SET_POMP_IDLE;  shurt = SET_POMP_HURT;  swalk = SET_POMP_WALK;  srun = SET_POMP_RUN;  sattack = SET_POMP_ATTACK; offY = -6; break;
    case T_GANG:  sidle = SET_GANG_IDLE;  shurt = SET_GANG_HURT;  swalk = SET_GANG_WALK;  srun = SET_GANG_RUN;  sattack = SET_GANG_RUN; break;
    default:      sidle = SET_SHLD_IDLE;  shurt = SET_SHLD_HURT;  swalk = SET_SHLD_WALK;  srun = SET_SHLD_RUN;  sattack = SET_SHLD_RUN; break;
    }
    int set = sidle;
    switch (e->action) {
    case ACT_IDLE:   set = sidle; if (e->type == T_GANG) offY = -13; break;
    case ACT_RUN:    set = srun; break;
    case ACT_WALK:   set = swalk; break;
    case ACT_ATTACK: set = sattack; break;
    case ACT_HURT:
        set = shurt;
        if (e->type == T_GRUNT) offY = -3;
        else if (e->type == T_GANG) offY = 5;
        break;
    }
    int n = SET_COUNT[set];
    int idx = (int)((G.frame / 2) % n);

    if (e->isHurtGround) {
        if (e->currentHurtGroundIdx < e->hurtGroundFrames) {
            idx = e->currentHurtGroundIdx;
            if (G.frame % 2 == 0) e->currentHurtGroundIdx++;
            if (e->type == T_SHLD) offY = idx < 7 ? 14 : 21;
        } else {
            idx = e->hurtGroundFrames - 1;
            if (e->type == T_SHLD) offY = 21;
        }
    } else if (e->isAttack) {
        if (e->currentAttackIdx < ATTACK_FRAMES) {
            idx = e->currentAttackIdx;
            if (G.frame % 2 == 0) e->currentAttackIdx++;
        } else {
            e->currentAttackIdx = 0;
            e->isAttack = 0;
            if (e->punch) { enqueue(e->punch, 0); e->punch = NULL; }
        }
    }
    if (idx >= n) idx = n - 1;
    draw_rect(gfx_img(set, idx), e, offX, offY, e->isFacingLeft || e->atLeft);
}

/* ---- Zero ---------------------------------------------------------------------- */
static int dead_screen_now(void)
{
    return zero->deathSoundPlayed && zero->currentHurtGroundIdx == zero->hurtGroundFrames - 1;
}

static void zero_hurt(Ent *obj)
{
    Ent *z = zero;
    z->dx = (z->cx - obj->cx) * 2;
    z->dy = z->cy - obj->cy;
    z->isProtected = 1;
    z->isHurtGround = 1;
    z->xVelocity = 0;
    z->yVelocity = 0;
    if (!z->deathSoundPlayed) {
        if (obj->type == T_PUNCH) sfx_play("enemy/punch_hit");
        else if (obj->type == T_BULLET) sfx_play("bullet/death_bullet");
        sfx_playf("zero/death_generic_%d", rnd(3) + 1);
        sfx_play("zero/playerdie");
        z->deathSoundPlayed = 1;
    }
    add_blood(obj->theta, z);
}

static void scroll_map(void)
{
    int lb = G.viewX + 300;
    if (zero->bb.x < lb) G.viewX -= lb - zero->bb.x;
    int rb = G.viewX + DIMW - 300;
    if (zero->bb.x + zero->bb.w > rb) G.viewX += zero->bb.x + zero->bb.w - rb;
    int tb = G.viewY + 150;
    if (zero->bb.y < tb) G.viewY -= tb - zero->bb.y;
    int bb = G.viewY + DIMH - 150;
    if (zero->bb.y + zero->bb.h > bb) G.viewY += zero->bb.y + zero->bb.h - bb;
}

static void zero_move(void)
{
    Ent *z = zero;
    char_move(z);
    if (!z->isFlipping) {
        if (z->isRunning) {
            if (z->isFacingLeft) { if (z->xVelocity < -z->maxXVelocity) z->xVelocity = -z->maxXVelocity; }
            else { if (z->xVelocity > z->maxXVelocity) z->xVelocity = z->maxXVelocity; }
            if (z->isFacingLeft && z->xVelocity > 0) z->xVelocity = -z->xVelocity;
            if (!z->isFacingLeft && z->xVelocity < 0) z->xVelocity = -z->xVelocity;

            if (!on_platform(z) && (on_left_wall(z) || on_right_wall(z))) {
                z->yVelocity = 3;
                z->xVelocity = 0;
            } else if (fabs(z->xVelocity) < z->maxXVelocity) {
                z->xVelocity += z->isFacingLeft ? -z->xAccelerate : z->xAccelerate;
            }
        } else if (z->xVelocity != 0) {
            if (z->xVelocity > 0)
                z->xVelocity = z->xVelocity > z->xSlowdownAccelerate ? z->xVelocity - z->xSlowdownAccelerate : 0;
            else
                z->xVelocity = fabs(z->xVelocity) > z->xSlowdownAccelerate ? z->xVelocity + z->xSlowdownAccelerate : 0;
        }
    }
    if (!on_platform(z)) {
        if (fabs(z->yVelocity) <= z->maxYVelocity) z->yVelocity -= -1.6;
    }
    z->dx = z->xVelocity;
    z->dy = z->yVelocity;
    scroll_map();
}

static void zero_draw(void)
{
    Ent *z = zero;
    int set, offX = 0, offY = 0;
    int onL = 0, onR = 0;

    if (z->isHurtGround) set = SET_ZERO_HURT;
    else if (z->isAttack) set = SET_ZERO_ATTACK;
    else if (z->isRolling) { set = SET_ZERO_ROLL; offY = 1; }
    else if (z->isFlipping) {
        onL = on_left_wall(z); onR = on_right_wall(z);
        if ((onL || onR) && z->currentFlipIdx != 0) { set = SET_ZERO_WALLSLIDE; offX = 20; }
        else set = SET_ZERO_FLIP;
    } else if ((on_left_wall(z) || on_right_wall(z)) && z->isRunning && !on_platform(z)) {
        set = SET_ZERO_WALLSLIDE; offX = 20;
    } else if (on_platform(z)) {
        if (z->isRunning) { set = SET_ZERO_RUN; offY = 1; }
        else { set = SET_ZERO_STAND; offY = 1; }
    } else {
        set = (z->dy <= 0) ? SET_ZERO_JUMP : SET_ZERO_FALL;
    }

    int n = SET_COUNT[set];
    int idx = (int)((G.frame / 2) % n);

    if (z->isHurtGround) {
        offY = 13;
        if (z->currentHurtGroundIdx < z->hurtGroundFrames) { idx = z->currentHurtGroundIdx; z->currentHurtGroundIdx++; }
        else idx = z->hurtGroundFrames - 1;
    } else if (z->isAttack) {
        if (z->currentAttackIdx < ATTACK_FRAMES) { idx = z->currentAttackIdx; z->currentAttackIdx++; }
        else {
            z->currentAttackIdx = 0;
            z->isAttack = 0;
            if (z->katana) enqueue(z->katana, 0);
            z->katana = NULL;
        }
    } else if (z->isRolling) {
        if (z->currentRollIdx < 7) {
            idx = z->currentRollIdx; z->currentRollIdx++;
            if (!z->isProtected) z->isProtected = 1;
        } else {
            z->currentRollIdx = 0; z->isRolling = 0; z->isProtected = 0;
        }
    } else if (z->isFlipping) {
        if (!(on_left_wall(z) || on_right_wall(z))) {
            if (z->currentFlipIdx < 11) { idx = z->currentFlipIdx; z->currentFlipIdx++; }
            else { z->currentFlipIdx = 0; z->isFlipping = 0; }
        } else if (z->currentFlipIdx != 0) {
            z->currentFlipIdx = 0; z->isFlipping = 0;
        }
    }
    if (idx >= n) idx = n - 1;
    draw_rect(gfx_img(set, idx), z, offX, offY, z->isFacingLeft);
}

/* ---- demais entidades ---------------------------------------------------------- */
static void door_move(Ent *e)
{
    if (e->isInfinite || e->enemySpawned < e->enemyNumToSpawn) {
        if (G.frame % 150 == 0 && rnd(2) == 1) {
            int t = rnd(15);
            if (!e->isInfinite) e->enemySpawned++;
            int x = e->cx, y = e->cy + BLOCK / 2;
            if (t < 5) new_enemy(T_GRUNT, x, y);
            else if (t < 10) new_enemy(T_POMP, x, y);
            else if (t < 13) new_enemy(T_GANG, x, y);
            else new_enemy(T_SHLD, x, y);
        }
    }
}

static void blood_draw(Ent *e)
{
    draw_at_rot(gfx_img(SET_BLOOD_BG, e->bgBloodIdx), e, e->bgBloodLeft);
    if (e->isSplatter) {
        if (e->splatIdx < 3) {
            int pic = e->splatIdx;
            if (G.frame % 8 == 0) e->splatIdx++;
            for (int k = 0; k < 6; k++)
                draw_at_rot(gfx_img(SET_BLOOD_SPLAT_0 + e->sp[k], pic), e, 0);
        } else e->isSplatter = 0;
    }
}

static void ent_move(Ent *e)
{
    switch (e->type) {
    case T_GRUNT: case T_POMP: case T_GANG: case T_SHLD: enemy_move(e); break;
    case T_ZERO: zero_move(); break;
    case T_BLOCK: break;
    case T_DOOR: door_move(e); break;
    case T_BULLET:
        sprite_move(e);
        e->dx = e->bvx; e->dy = e->bvy;
        break;
    default: sprite_move(e); break;
    }
}

static void ent_draw(Ent *e)
{
    switch (e->type) {
    case T_GRUNT: case T_POMP: case T_GANG: case T_SHLD: enemy_draw(e); break;
    case T_ZERO: zero_draw(); break;
    case T_BLOCK: draw_at(gfx_img(SET_BRICK, 0), e->cx - G.viewX, e->cy - G.viewY, 0); break;
    case T_DOOR: draw_at(gfx_img(SET_DOOR, 0), e->cx - G.viewX, e->cy - G.viewY, 0); break;
    case T_BULLET: draw_at(gfx_img(SET_BULLET, 0), e->cx - G.viewX, e->cy - G.viewY, 0); break;
    case T_BLOOD: blood_draw(e); break;
    case T_HITSLASH:
        draw_at_rot(gfx_img(SET_FX_HITSLASH, e->index), e, 0); e->index++; break;
    case T_NSLASH:
        draw_at_rot(gfx_img(SET_FX_SLASH, e->index), e, 0); e->index++; break;
    case T_JUMPCLOUD:
        draw_at_rot(gfx_img(SET_FX_JUMPCLOUD, e->index), e, 0); e->index++; break;
    case T_BREFLECT:
        draw_at_rot(gfx_img(SET_FX_BULLETREFLECT, e->index), e, 0); e->index++; break;
    default: break;
    }
}

static void run_list(List *l)
{
    int n = l->n;                       /* ops sao adiadas, a lista nao muda aqui */
    for (int i = 0; i < n; i++) { ent_move(l->a[i]); ent_draw(l->a[i]); }
}

/* ---- colisoes ------------------------------------------------------------------ */
static void check_player_attack(void)
{
    Ent *z = zero;
    if (!z->isAttack || !z->katana) return;
    Ent *k = z->katana;
    for (int i = 0; i < enemies.n; i++) {
        Ent *en = enemies.a[i];
        if (dist(k, en) < k->radius + MIN_RADIUS && !en->isProtected) {
            if (!k->hitSlashMade) {
                int ang = (int)(atan2((double)(en->cy - k->cy), (double)(en->cx - k->cx)) * 180.0 / 3.14159265358979323846);
                add_debris(T_HITSLASH, 4, en, en->cx, en->cy, ang);
                k->hitSlashMade = 1;
            }
            enemy_hurt(en, k);
            sfx_playf("enemy/sound_enemy_death_sword_0%d", rnd(2) + 1);
            sfx_play("enemy/sound_enemy_death_generic");
            G.enemyNums--;
            G.score += 100;
        }
    }
    for (int i = 0; i < bullets.n; i++) {
        Ent *b = bullets.a[i];
        if (!b->isReflected && dist(k, b) < k->radius + b->radius) {
            if (!k->reflectMade) {
                add_debris(T_BREFLECT, 5, NULL, k->cx, k->cy, 0);
                k->reflectMade = 1;
            }
            sfx_play("bullet/slash_bullet");
            b->isReflected = 1;
            b->bvy = -b->bvy;
            b->bvx = -b->bvx * 3;
        }
    }
}

static void check_enemy_attack(void)
{
    Ent *z = zero;
    if (!z->isProtected) {
        for (int i = 0; i < punches.n; i++) {
            Ent *p = punches.a[i];
            if (dist(p, z) < p->radius + z->radius) zero_hurt(p);
        }
    }
    for (int i = 0; i < bullets.n; i++) {
        Ent *b = bullets.a[i];
        if (!b->isReflected) {
            if (!z->isProtected && dist(b, z) < b->radius + z->radius) {
                zero_hurt(b);
                enqueue(b, 0);
            }
        } else {
            for (int j = 0; j < enemies.n; j++) {
                Ent *en = enemies.a[j];
                if (dist(b, en) < en->radius + b->radius && !en->isProtected) {
                    enqueue(b, 0);
                    enemy_hurt(en, b);
                    sfx_play("bullet/sound_enemy_death_bullet");
                    sfx_play("enemy/sound_enemy_death_generic");
                    G.enemyNums--;
                    G.score += 100;
                }
            }
        }
    }
    for (int i = 0; i < bullets.n; i++)
        for (int j = 0; j < floors.n; j++)
            if (dist(bullets.a[i], floors.a[j]) < bullets.a[i]->radius + floors.a[j]->radius)
                enqueue(bullets.a[i], 0);
}

static int enemy_run_snd = 1;
static void check_enemy_view(void)
{
    Ent *z = zero;
    for (int i = 0; i < enemies.n; i++) {
        Ent *en = enemies.a[i];
        if (en->isProtected || z->isProtected) continue;
        double d = dist(z, en);
        if (d < z->radius + en->viewRadius) {
            if (d < z->radius + en->attackRadius) {
                set_chasing(en, 0);
                en->canAttack = 1;
                en->atLeft = z->cx < en->cx;
                enemy_attack(en);
            } else {
                en->canAttack = 0;
                set_chasing(en, 1);
                en->isNoticed = 1;
                if (G.frame % 6 == 0) {
                    sfx_playf("enemy/sound_generic_enemy_run_%d", enemy_run_snd % 4 + 1);
                    enemy_run_snd++;
                    if (enemy_run_snd > 10000) enemy_run_snd = 0;
                }
                en->atLeft = z->cx < en->cx;
            }
        } else {
            set_chasing(en, 0);
        }
    }
}

/* ---- texto das telas de status ---------------------------------------------------- */
static void text_lines(const char **lines, int n)
{
    int y = 70;
    for (int i = 0; i < n; i++, y += 24)
        if (lines[i][0]) gfx_text_center(SCR_W / 2, y, lines[i], 0xFFFFFFFFu);
}

int game_dead_screen(void) { return dead_screen_now(); }
int game_input_blocked(void)
{
    return G.paused || G.levelCleared || zero->deathSoundPlayed;
}

static int bg_for_level(int l) { return l < 0 ? 0 : (l > 8 ? 8 : l); }

void game_frame(void)
{
    gfx_clear(0xFF000000u);
    char score[64];

    if (dead_screen_now()) {
        snprintf(score, sizeof(score), "Score: %ld", G.score);
        const char *l1[] = {"No... That won't work", "", G.currentLevel == 8 ? score : "", "",
                            "TRIANGLE - level selection", "CIRCLE - restart this level", "SELECT - quit game"};
        text_lines(l1, 7);
    } else if (G.levelCleared) {
        const char *l2[] = {"Yes, that should work.", "", "", "", "CROSS - next level",
                            "TRIANGLE - level selection", "CIRCLE - restart this level", "SELECT - quit game"};
        text_lines(l2, 8);
    } else if (G.paused) {
        const char *l3[] = {"Game Paused", "", "SQUARE / R1 - ATTACK", "CIRCLE - ROLL", "CROSS - JUMP",
                            "L1 / L2 / R2 - SLOW MOTION", "RIGHT STICK - AIM", "START - continue",
                            "CIRCLE - restart this level", "TRIANGLE - level selection", "SELECT - quit game"};
        text_lines(l3, 11);
    } else {
        gfx_copy_full(gfx_img(SET_BG, bg_for_level(G.currentLevel)), 0, 0);
        run_list(&backg);
        run_list(&bloods);
        run_list(&floors);
        if (G.slowmo) gfx_fill_alpha(0, 0, SCR_W, SCR_H, 0xB0080808u);
        run_list(&enemies);
        run_list(&friends);
        run_list(&katanas);
        run_list(&punches);
        run_list(&bullets);
        run_list(&debris);
        if (G.aim_show) {
            const Img *c = gfx_img(SET_CURSOR, 0);
            int sx = ((zero->cx - G.viewX) + G.aimx) / 2 - c->w / 2;
            int sy = ((zero->cy - G.viewY) + G.aimy) / 2 - c->h / 2;
            gfx_blit(c, sx, sy);
        }
    }

    if (!G.paused) {
        check_player_attack();
        check_enemy_attack();
        check_enemy_view();
        process_ops();
        if (G.frame % 150 == 0 && G.levelInited && G.enemyNums == 0 && G.currentLevel != 8)
            G.levelCleared = 1;
        G.frame++;
    }
}

/* ---- carregamento de fase ------------------------------------------------------------ */
static void clear_all(void)
{
    floors.n = friends.n = enemies.n = backg.n = bloods.n = katanas.n = punches.n =
        bullets.n = debris.n = 0;
    nops = 0;
    nfree = 0;
    for (int i = 0; i < POOL; i++) { pool[i].used = 0; freelist[nfree++] = &pool[i]; }
}

void game_load_level(int level)
{
    clear_all();
    G.score = 0;
    G.paused = 0;
    G.enemyNums = 0;
    G.currentLevel = level;
    zero_reset(300, 240);

    char path[300];
    snprintf(path, sizeof(path), "%s/maps/level_%d.csv", dir_data, level);
    FILE *f = fopen(path, "r");
    if (f) {
        char line[1024];
        int row = 0;
        while (fgets(line, sizeof(line), f)) {
            int col = 0;
            char *p = line;
            for (;;) {
                char *q = p;
                while (*q && *q != ',' && *q != '\n' && *q != '\r') q++;
                int has = q > p;
                int v = has ? atoi(p) : -1;
                if (has) {
                    int x = col * BLOCK, y = row * BLOCK;
                    switch (v) {
                    case 0: set_cx(zero, x + BLOCK / 2); set_cy(zero, y + BLOCK / 2); break;
                    case 1: new_enemy(T_GRUNT, x + BLOCK / 2, y + BLOCK / 2); break;
                    case 2: new_enemy(T_POMP, x + BLOCK / 2, y + BLOCK / 2); break;
                    case 3: new_enemy(T_GANG, x + BLOCK / 2, y + BLOCK / 2); break;
                    case 4: new_enemy(T_SHLD, x + BLOCK / 2, y + BLOCK / 2); break;
                    case 5: {
                        Ent *b = ent_new(T_BLOCK, TEAM_FLOOR);
                        if (b) {
                            b->radius = BLOCK / 2; b->hasbb = 1;
                            b->bb.x = x; b->bb.y = y; b->bb.w = b->bb.h = BLOCK;
                            b->cx = x + BLOCK / 2; b->cy = y + BLOCK / 2;
                            enqueue(b, 1);
                        }
                        break; }
                    case 6: case 7: {
                        Ent *d = ent_new(T_DOOR, TEAM_BACKGROUND);
                        if (d) {
                            d->radius = 36; d->hasbb = 1;
                            d->bb.x = x; d->bb.y = y; d->bb.w = BLOCK; d->bb.h = BLOCK * 3 / 2;
                            d->cx = x + BLOCK / 2; d->cy = y + BLOCK;
                            d->isInfinite = (v == 7);
                            if (!d->isInfinite) d->enemyNumToSpawn = rnd(5);
                            enqueue(d, 1);
                        }
                        break; }
                    }
                }
                col++;
                if (*q == ',') p = q + 1; else break;
            }
            row++;
        }
        fclose(f);
    }
    enqueue(zero, 1);
    G.levelInited = 1;
    G.levelCleared = 0;
    G.slowmo = 0;
    G.aim_show = 0;
    /* a camera comeca em cima do Zero */
    G.viewX = zero->cx - DIMW / 2;
    G.viewY = zero->cy - DIMH / 2;
}

int game_init(const char *data_dir)
{
    snprintf(dir_data, sizeof(dir_data), "%s", data_dir);
    char p[300];
    snprintf(p, sizeof(p), "%s/sprites.bin", data_dir);
    int r = gfx_load_sprites(p);
    if (r) return r;
    memset(&G, 0, sizeof(G));
    clear_all();
    zero_reset(300, 240);
    return 0;
}

int game_song_for_level(int level) { return level / 2; }

/* ---- entrada ---------------------------------------------------------------------------- */
static int run_prev = 0;
static long last_run_snd_frame = -1;
static int run_snd_idx = 1;

void game_set_run(int dir)
{
    Ent *z = zero;
    if (dir != 0) {
        if (!z->isAttack && !z->isRolling) {
            z->isFacingLeft = dir < 0;
            z->isRunning = 1;
            if (G.frame % 6 == 0 && G.frame != last_run_snd_frame && (dir > 0 || on_platform(z))) {
                sfx_playf("zero/player_running_%d", run_snd_idx % 4 + 1);
                run_snd_idx++;
                if (run_snd_idx > 10000) run_snd_idx = 0;
                last_run_snd_frame = G.frame;
            }
        }
    } else if (run_prev != 0) {
        z->isRunning = 0;
        z->run2IdleFlag = 4;
    }
    run_prev = dir;
}

void game_jump(void)
{
    Ent *z = zero;
    if (on_platform(z) && !z->isRolling) {
        if (z->isRunning && (on_left_wall(z) || on_right_wall(z))) {
            sfx_play("zero/player_jump");
            z->yVelocity = -z->maxYVelocity / 2;
        } else {
            sfx_play("zero/player_jump");
            add_debris(T_JUMPCLOUD, 4, z, z->cx, z->cy, 0);
            z->yVelocity = -24;
        }
    } else if (z->isRunning) {
        if (on_left_wall(z)) {
            z->isFlipping = 1; z->isFacingLeft = 0;
            sfx_play("zero/player_jump");
            z->xVelocity = z->maxXVelocity;
            z->yVelocity = -z->maxYVelocity * 2 / 3;
        } else if (on_right_wall(z)) {
            z->isFlipping = 1; z->isFacingLeft = 1;
            sfx_play("zero/player_jump");
            z->xVelocity = -z->maxXVelocity;
            z->yVelocity = -z->maxYVelocity * 2 / 3;
        }
    }
}

void game_down(void)
{
    Ent *z = zero;
    if (on_platform(z)) {
        if (!z->isRolling) {
            z->isRolling = 1;
            sfx_play("zero/player_roll");
            z->xVelocity = z->isFacingLeft ? -z->maxXVelocity * 3 : z->maxXVelocity * 3;
        }
    } else {
        z->yVelocity += 10;
        z->dy += 14;
    }
}

void game_attack(int ax, int ay)
{
    Ent *z = zero;
    if (z->isAttack) return;
    sfx_playf("zero/slash_%d", rnd(3) + 1);

    double theta = atan2((double)ay, (double)ax);
    int ang = (int)(theta * 180.0 / 3.14159265358979323846);
    add_debris(T_NSLASH, 5, z, z->cx, z->cy, ang);

    Ent *k = ent_new(T_KATANA, TEAM_KATANA);
    if (k) {
        k->theta = theta;
        k->radius = 36;
        if (ax == 0 && ay == 0) { k->cx = z->cx; k->cy = z->cy; }
        else {
            k->cx = (int)(z->cx + z->radius * cos(theta));
            k->cy = (int)(z->cy + z->radius * sin(theta));
        }
        enqueue(k, 1);
        z->katana = k;
    }
    z->isAttack = 1;

    if (ay < 0) {
        z->yVelocity = -z->maxYVelocity / 2;
        z->dy -= 7;
    }
    if (ax < 0 || (ax == 0 && z->isFacingLeft)) {
        z->isFacingLeft = 1;
        z->xVelocity = -z->maxXVelocity * 2;
    } else {
        z->isFacingLeft = 0;
        z->xVelocity = z->maxXVelocity * 2;
    }
}

static int slowmo_snd = -1;
static unsigned slowmo_t0 = 0;
void game_slowmo_start(unsigned now)
{
    if (G.slowmo) return;
    slowmo_snd = sfx_play("zero/yxqr1-n8ca2");
    G.slowmo = 1;
    slowmo_t0 = now;
}
void game_slowmo_end(void)
{
    if (!G.slowmo) return;
    G.slowmo = 0;
    sfx_stop(slowmo_snd);
    sfx_play("zero/slowmo_exit");
}
void game_slowmo_tick(unsigned now)
{
    if (G.slowmo && now - slowmo_t0 > 5000) game_slowmo_end();
}

static void clear_flags(void)
{
    G.levelInited = 0;
    G.levelCleared = 0;
}
void game_restart_level(void)
{
    clear_flags();
    game_load_level(G.currentLevel);
}
int game_next_level(void)
{
    if (G.levelCleared && G.currentLevel < 8) {
        clear_flags();
        game_load_level(G.currentLevel + 1);
        return 1;
    }
    return 0;
}
void game_prepare_level_select(void)
{
    clear_flags();
    game_slowmo_end();
}
