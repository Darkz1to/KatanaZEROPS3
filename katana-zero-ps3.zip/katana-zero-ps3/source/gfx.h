/* Renderizador por software em um buffer 640x360 ARGB.
 * O buffer e enviado para a tela (escalado por hardware) em main.c. */
#ifndef GFX_H
#define GFX_H

#include <stdint.h>

#define SCR_W 640
#define SCR_H 360

typedef struct {
    int w, h;
    uint32_t *px;          /* ARGB 0xAARRGGBB */
} Img;

extern uint32_t fb[SCR_W * SCR_H];

int  gfx_load_sprites(const char *path);     /* sprites.bin; 0 = ok */
const Img *gfx_img(int set, int idx);

void gfx_clear(uint32_t argb);
void gfx_copy_full(const Img *im, int x, int y);          /* sem alpha (fundos) */
void gfx_blit(const Img *im, int x, int y);               /* com alpha */
void gfx_blit_flip(const Img *im, int x, int y);          /* espelhado em X */
void gfx_blit_rot(const Img *im, double cx, double cy, double deg, int flip);
void gfx_fill_alpha(int x, int y, int w, int h, uint32_t argb);
void gfx_frame_rect(int x, int y, int w, int h, int t, uint32_t argb);

int  gfx_text_w(const char *s);
void gfx_text(int x, int y, const char *s, uint32_t argb);
void gfx_text_center(int cx, int y, const char *s, uint32_t argb);

#endif
