#include "audio.h"

#include <SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STB_VORBIS_NO_PUSHDATA_API
#include "../third_party/stb_vorbis.c"

#define MAX_SFX    64
#define MAX_VOICES 16

typedef struct {
    char name[48];
    int frames;
    int16_t *pcm;
} Sfx;

typedef struct {
    const Sfx *s;
    int pos;
    int id;          /* handle unico */
    int active;
} Voice;

static Sfx sfx_tab[MAX_SFX];
static int sfx_n = 0;

static Voice voices[MAX_VOICES];
static int next_voice_id = 1;

static SDL_AudioDeviceID dev = 0;
static SDL_AudioSpec have;
static char base_dir[256];

static stb_vorbis *mus = NULL;
static short mus_buf[2048 * 2];

#define SFX_GAIN   (0.80f / 32768.0f)
#define MUSIC_GAIN (0.40f / 32768.0f)

static int load_sfx_bank(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return -1;
    unsigned char hdr[8];
    if (fread(hdr, 1, 8, f) != 8 || memcmp(hdr, "KZSX", 4) != 0) { fclose(f); return -2; }
    unsigned n = ((unsigned)hdr[4] << 24) | (hdr[5] << 16) | (hdr[6] << 8) | hdr[7];
    for (unsigned i = 0; i < n && sfx_n < MAX_SFX; i++) {
        unsigned char ln;
        if (fread(&ln, 1, 1, f) != 1) break;
        Sfx *s = &sfx_tab[sfx_n];
        memset(s, 0, sizeof(*s));
        if (ln >= sizeof(s->name)) { fclose(f); return -3; }
        if (fread(s->name, 1, ln, f) != ln) break;
        unsigned char fr[4];
        if (fread(fr, 1, 4, f) != 4) break;
        s->frames = (int)(((unsigned)fr[0] << 24) | (fr[1] << 16) | (fr[2] << 8) | fr[3]);
        unsigned char *raw = (unsigned char *)malloc((size_t)s->frames * 2);
        s->pcm = (int16_t *)malloc((size_t)s->frames * 2);
        if (!raw || !s->pcm) { free(raw); fclose(f); return -4; }
        if (fread(raw, 1, (size_t)s->frames * 2, f) != (size_t)s->frames * 2) { free(raw); break; }
        for (int k = 0; k < s->frames; k++)
            s->pcm[k] = (int16_t)((raw[k * 2] << 8) | raw[k * 2 + 1]);
        free(raw);
        sfx_n++;
    }
    fclose(f);
    return 0;
}

static void audio_cb(void *ud, Uint8 *stream, int len)
{
    (void)ud;
    int is_float = SDL_AUDIO_ISFLOAT(have.format);
    int bytes_per = is_float ? 4 : 2;
    int ch = have.channels ? have.channels : 2;
    int frames = len / (bytes_per * ch);

    static float mix[4096 * 2];
    if (frames > 4096) frames = 4096;
    memset(mix, 0, sizeof(float) * frames * 2);

    /* musica */
    if (mus) {
        int got = 0;
        while (got < frames) {
            int want = frames - got;
            if (want > 2048) want = 2048;
            int n = stb_vorbis_get_samples_short_interleaved(mus, 2, mus_buf, want * 2);
            if (n <= 0) { stb_vorbis_seek_start(mus); continue; }
            for (int i = 0; i < n; i++) {
                mix[(got + i) * 2]     += mus_buf[i * 2]     * MUSIC_GAIN;
                mix[(got + i) * 2 + 1] += mus_buf[i * 2 + 1] * MUSIC_GAIN;
            }
            got += n;
        }
    }

    /* efeitos */
    for (int v = 0; v < MAX_VOICES; v++) {
        Voice *vo = &voices[v];
        if (!vo->active) continue;
        const Sfx *s = vo->s;
        int n = s->frames - vo->pos;
        if (n > frames) n = frames;
        for (int i = 0; i < n; i++) {
            float x = s->pcm[vo->pos + i] * SFX_GAIN;
            mix[i * 2] += x;
            mix[i * 2 + 1] += x;
        }
        vo->pos += n;
        if (vo->pos >= s->frames) vo->active = 0;
    }

    /* saida */
    if (is_float && have.format == AUDIO_F32SYS) {
        float *o = (float *)stream;
        for (int i = 0; i < frames; i++) {
            float l = mix[i * 2], r = mix[i * 2 + 1];
            if (l > 1.f) l = 1.f; else if (l < -1.f) l = -1.f;
            if (r > 1.f) r = 1.f; else if (r < -1.f) r = -1.f;
            o[i * ch] = l;
            if (ch > 1) o[i * ch + 1] = r;
            for (int c = 2; c < ch; c++) o[i * ch + c] = 0.f;
        }
    } else if (!is_float && have.format == AUDIO_S16SYS) {
        int16_t *o = (int16_t *)stream;
        for (int i = 0; i < frames; i++) {
            float l = mix[i * 2], r = mix[i * 2 + 1];
            if (l > 1.f) l = 1.f; else if (l < -1.f) l = -1.f;
            if (r > 1.f) r = 1.f; else if (r < -1.f) r = -1.f;
            o[i * ch] = (int16_t)(l * 32767.f);
            if (ch > 1) o[i * ch + 1] = (int16_t)(r * 32767.f);
            for (int c = 2; c < ch; c++) o[i * ch + c] = 0;
        }
    } else {
        memset(stream, 0, len);
    }
    if (frames * bytes_per * ch < len)
        memset(stream + frames * bytes_per * ch, 0, len - frames * bytes_per * ch);
}

int audio_init(const char *data_dir)
{
    snprintf(base_dir, sizeof(base_dir), "%s", data_dir);
    char p[320];
    snprintf(p, sizeof(p), "%s/sfx.bin", data_dir);
    load_sfx_bank(p);

    SDL_AudioSpec want;
    SDL_zero(want);
    want.freq = 48000;
    want.format = AUDIO_F32SYS;
    want.channels = 2;
    want.samples = 1024;
    want.callback = audio_cb;
    dev = SDL_OpenAudioDevice(NULL, 0, &want, &have, SDL_AUDIO_ALLOW_ANY_CHANGE);
    if (dev == 0) return -1;
    SDL_PauseAudioDevice(dev, 0);
    return 0;
}

void audio_shutdown(void)
{
    if (dev) { SDL_CloseAudioDevice(dev); dev = 0; }
    if (mus) { stb_vorbis_close(mus); mus = NULL; }
}

int sfx_play(const char *name)
{
    if (!dev) return -1;
    const Sfx *s = NULL;
    for (int i = 0; i < sfx_n; i++)
        if (strcmp(sfx_tab[i].name, name) == 0) { s = &sfx_tab[i]; break; }
    if (!s) return -1;

    SDL_LockAudioDevice(dev);
    int slot = -1, oldest = 0, oldest_pos = -1;
    for (int v = 0; v < MAX_VOICES; v++) {
        if (!voices[v].active) { slot = v; break; }
        if (voices[v].pos > oldest_pos) { oldest_pos = voices[v].pos; oldest = v; }
    }
    if (slot < 0) slot = oldest;
    voices[slot].s = s;
    voices[slot].pos = 0;
    voices[slot].active = 1;
    voices[slot].id = next_voice_id++;
    int id = voices[slot].id;
    SDL_UnlockAudioDevice(dev);
    return id;
}

void sfx_playf(const char *fmt, int n)
{
    char buf[64];
    snprintf(buf, sizeof(buf), fmt, n);
    sfx_play(buf);
}

void sfx_stop(int handle)
{
    if (!dev || handle < 0) return;
    SDL_LockAudioDevice(dev);
    for (int v = 0; v < MAX_VOICES; v++)
        if (voices[v].active && voices[v].id == handle) voices[v].active = 0;
    SDL_UnlockAudioDevice(dev);
}

void music_play(const char *file)
{
    if (!dev) return;
    stb_vorbis *n = NULL;
    if (file) {
        char p[360];
        snprintf(p, sizeof(p), "%s/music/%s", base_dir, file);
        int err = 0;
        n = stb_vorbis_open_filename(p, &err, NULL);
    }
    SDL_LockAudioDevice(dev);
    stb_vorbis *old = mus;
    mus = n;
    SDL_UnlockAudioDevice(dev);
    if (old) stb_vorbis_close(old);
}
