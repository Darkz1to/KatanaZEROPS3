#include "audio.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <stdint.h>
#include <unistd.h>
#include <audio/audio.h>
#include <sys/thread.h>

#define STB_VORBIS_NO_PUSHDATA_API
#include "../third_party/stb_vorbis.c"

#define MAX_SFX    64
#define MAX_VOICES 16

typedef struct {
    char name[48];
    int frames;
    int16_t *pcm;
} Sfx;

typedef struct {
    const Sfx *s;
    int pos;
    int id;          /* handle unico */
    int active;
} Voice;

static Sfx sfx_tab[MAX_SFX];
static int sfx_n = 0;

static Voice voices[MAX_VOICES];
static int next_voice_id = 1;

/* Audio nativo (libaudio do PSL1GHT): porta estereo, float, 48 kHz, blocos de
 * 256 amostras. Uma thread propria mistura e preenche os blocos que o
 * hardware ja leu. */
#define BLOCK_SAMPLES 256

static int dev = 0;                   /* 1 = audio aberto */
static u32 port_num = 0;
static audioPortConfig pcfg;
static sys_ppu_thread_t audio_thr;
static volatile int audio_run = 0;
static volatile int in_mus = 0;       /* a thread de audio esta usando 'mus' */
static char base_dir[256];

#define SYNC() __asm__ volatile("sync" ::: "memory")

static stb_vorbis * volatile mus = NULL;
static short mus_buf[2048 * 2];
/* A musica inteira fica em RAM e o stb_vorbis usa um buffer fixo: assim a
 * thread de audio nao usa malloc/free nem le arquivos (isso podia travar o
 * heap compartilhado com a thread principal no PS3). */
typedef struct { unsigned char *data; unsigned char *heap; stb_vorbis *v; } Track;
static Track cur_track;
#define VORBIS_HEAP (6 * 1024 * 1024)

#define SFX_GAIN   (0.80f / 32768.0f)
#define MUSIC_GAIN (0.40f / 32768.0f)

static int load_sfx_bank(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return -1;
    unsigned char hdr[8];
    if (fread(hdr, 1, 8, f) != 8 || memcmp(hdr, "KZSX", 4) != 0) { fclose(f); return -2; }
    unsigned n = ((unsigned)hdr[4] << 24) | (hdr[5] << 16) | (hdr[6] << 8) | hdr[7];
    for (unsigned i = 0; i < n && sfx_n < MAX_SFX; i++) {
        unsigned char ln;
        if (fread(&ln, 1, 1, f) != 1) break;
        Sfx *s = &sfx_tab[sfx_n];
        memset(s, 0, sizeof(*s));
        if (ln >= sizeof(s->name)) { fclose(f); return -3; }
        if (fread(s->name, 1, ln, f) != ln) break;
        unsigned char fr[4];
        if (fread(fr, 1, 4, f) != 4) break;
        s->frames = (int)(((unsigned)fr[0] << 24) | (fr[1] << 16) | (fr[2] << 8) | fr[3]);
        unsigned char *raw = (unsigned char *)malloc((size_t)s->frames * 2);
        s->pcm = (int16_t *)malloc((size_t)s->frames * 2);
        if (!raw || !s->pcm) { free(raw); fclose(f); return -4; }
        if (fread(raw, 1, (size_t)s->frames * 2, f) != (size_t)s->frames * 2) { free(raw); break; }
        for (int k = 0; k < s->frames; k++)
            s->pcm[k] = (int16_t)((raw[k * 2] << 8) | raw[k * 2 + 1]);
        free(raw);
        sfx_n++;
    }
    fclose(f);
    return 0;
}

/* mistura 'frames' amostras estereo float em out (intercalado L,R) */
static void mix_block(float *out, int frames)
{
    static float mix[BLOCK_SAMPLES * 2];
    memset(mix, 0, sizeof(float) * frames * 2);

    /* musica */
    in_mus = 1;
    SYNC();
    stb_vorbis *m = mus;
    if (m) {
        int got = 0, guard = 0;
        while (got < frames && guard++ < 4) {
            int want = frames - got;
            int n = stb_vorbis_get_samples_short_interleaved(m, 2, mus_buf, want * 2);
            if (n <= 0) { stb_vorbis_seek_start(m); continue; }
            for (int i = 0; i < n; i++) {
                mix[(got + i) * 2]     += mus_buf[i * 2]     * MUSIC_GAIN;
                mix[(got + i) * 2 + 1] += mus_buf[i * 2 + 1] * MUSIC_GAIN;
            }
            got += n;
        }
    }
    SYNC();
    in_mus = 0;

    /* efeitos */
    for (int v = 0; v < MAX_VOICES; v++) {
        Voice *vo = &voices[v];
        if (!vo->active) continue;
        SYNC();
        const Sfx *s = vo->s;
        int pos = vo->pos;
        int n = s->frames - pos;
        if (n > frames) n = frames;
        for (int i = 0; i < n; i++) {
            float x = s->pcm[pos + i] * SFX_GAIN;
            mix[i * 2] += x;
            mix[i * 2 + 1] += x;
        }
        vo->pos = pos + n;
        if (vo->pos >= s->frames) vo->active = 0;
    }

    for (int i = 0; i < frames * 2; i++) {
        float x = mix[i];
        if (x > 1.f) x = 1.f; else if (x < -1.f) x = -1.f;
        out[i] = x;
    }
}

static void audio_thread(void *arg)
{
    (void)arg;
    float *base = (float *)(uintptr_t)pcfg.audioDataStart;
    volatile u32 *rd = (volatile u32 *)(uintptr_t)pcfg.readIndex;
    u32 nblocks = (u32)pcfg.numBlocks;
    u32 next = 0;

    while (audio_run) {
        u32 ri = *rd;
        int did = 0;
        /* preenche os blocos que o hardware acabou de ler */
        while (next != ri && audio_run) {
            mix_block(base + (size_t)next * BLOCK_SAMPLES * 2, BLOCK_SAMPLES);
            next = (next + 1) % nblocks;
            did = 1;
        }
        if (!did) usleep(1000);
    }
    sysThreadExit(0);
}

int audio_init(const char *data_dir)
{
    snprintf(base_dir, sizeof(base_dir), "%s", data_dir);
    char p[320];
    snprintf(p, sizeof(p), "%s/sfx.bin", data_dir);
    load_sfx_bank(p);

    if (audioInit() != 0) return -1;

    audioPortParam params;
    memset(&params, 0, sizeof(params));
    params.numChannels = AUDIO_PORT_2CH;
    params.numBlocks = AUDIO_BLOCK_8;
    params.level = 1.0f;
    if (audioPortOpen(&params, &port_num) != 0) { audioQuit(); return -2; }
    if (audioGetPortConfig(port_num, &pcfg) != 0) { audioPortClose(port_num); audioQuit(); return -3; }

    memset((void *)(uintptr_t)pcfg.audioDataStart, 0,
           (size_t)pcfg.numBlocks * BLOCK_SAMPLES * 2 * sizeof(float));

    audio_run = 1;
    if (sysThreadCreate(&audio_thr, audio_thread, NULL, 1000, 256 * 1024,
                        THREAD_JOINABLE, (char *)"katana_audio") != 0) {
        audio_run = 0;
        audioPortClose(port_num);
        audioQuit();
        return -4;
    }
    dev = 1;
    audioPortStart(port_num);
    return 0;
}

void audio_shutdown(void)
{
    if (dev) {
        audio_run = 0;
        u64 ret;
        sysThreadJoin(audio_thr, &ret);
        audioPortStop(port_num);
        audioPortClose(port_num);
        audioQuit();
        dev = 0;
    }
    music_play(NULL);
}

int sfx_play(const char *name)
{
    if (!dev) return -1;
    const Sfx *s = NULL;
    for (int i = 0; i < sfx_n; i++)
        if (strcmp(sfx_tab[i].name, name) == 0) { s = &sfx_tab[i]; break; }
    if (!s) return -1;

    int slot = -1, oldest = 0, oldest_pos = -1;
    for (int v = 0; v < MAX_VOICES; v++) {
        if (!voices[v].active) { slot = v; break; }
        if (voices[v].pos > oldest_pos) { oldest_pos = voices[v].pos; oldest = v; }
    }
    if (slot < 0) slot = oldest;
    /* desliga a voz antes de trocar os campos; 'active' so volta no fim */
    voices[slot].active = 0;
    SYNC();
    voices[slot].s = s;
    voices[slot].pos = 0;
    voices[slot].id = next_voice_id++;
    int id = voices[slot].id;
    SYNC();
    voices[slot].active = 1;
    return id;
}

void sfx_playf(const char *fmt, int n)
{
    char buf[64];
    snprintf(buf, sizeof(buf), fmt, n);
    sfx_play(buf);
}

void sfx_stop(int handle)
{
    if (!dev || handle < 0) return;
    for (int v = 0; v < MAX_VOICES; v++)
        if (voices[v].active && voices[v].id == handle) voices[v].active = 0;
}

static void track_free(Track *t)
{
    if (t->v) stb_vorbis_close(t->v);
    free(t->data);
    free(t->heap);
    memset(t, 0, sizeof(*t));
}

void music_play(const char *file)
{
    if (!dev) return;
    Track nt;
    memset(&nt, 0, sizeof(nt));
    if (file) {
        char p[360];
        snprintf(p, sizeof(p), "%s/nomusic", base_dir);
        FILE *chk = fopen(p, "rb");
        if (chk) { fclose(chk); file = NULL; }
    }
    if (file) {
        char p[360];
        snprintf(p, sizeof(p), "%s/music/%s", base_dir, file);
        FILE *f = fopen(p, "rb");
        if (f) {
            fseek(f, 0, SEEK_END);
            long sz = ftell(f);
            fseek(f, 0, SEEK_SET);
            nt.data = (unsigned char *)malloc((size_t)sz);
            nt.heap = (unsigned char *)malloc(VORBIS_HEAP);
            if (nt.data && nt.heap && fread(nt.data, 1, (size_t)sz, f) == (size_t)sz) {
                stb_vorbis_alloc al;
                al.alloc_buffer = (char *)nt.heap;
                al.alloc_buffer_length_in_bytes = VORBIS_HEAP;
                int err = 0;
                nt.v = stb_vorbis_open_memory(nt.data, (int)sz, &err, &al);
            }
            fclose(f);
            if (!nt.v) track_free(&nt);
        }
    }
    /* tira a faixa antiga de uso e espera a thread de audio sair dela (maximo ~50 ms) */
    Track old = cur_track;
    mus = NULL;
    SYNC();
    for (int w = 0; w < 100 && in_mus; w++) usleep(500);
    cur_track = nt;
    SYNC();
    mus = nt.v;
    track_free(&old);
}
