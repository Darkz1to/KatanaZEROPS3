#ifndef AUDIO_H
#define AUDIO_H

int  audio_init(const char *data_dir);       /* 0 = ok (ou sem audio: continua mudo) */
void audio_shutdown(void);

/* efeitos: nome sem extensao, minusculo, ex. "zero/player_jump". Retorna handle (>=0) ou -1 */
int  sfx_play(const char *name);
void sfx_playf(const char *fmt, int n);     /* nome com um %d */
void sfx_stop(int handle);

void music_play(const char *file);          /* ex. "song_chinatown.ogg"; NULL = parar */

#endif
