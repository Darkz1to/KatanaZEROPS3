#ifndef GAME_H
#define GAME_H

#include <stdint.h>

typedef struct { int x, y, w, h; } Rect;

enum { T_ZERO, T_GRUNT, T_POMP, T_GANG, T_SHLD, T_BLOCK, T_DOOR, T_KATANA, T_PUNCH,
       T_BULLET, T_BLOOD, T_HITSLASH, T_NSLASH, T_JUMPCLOUD, T_BREFLECT };
enum { TEAM_FLOOR, TEAM_FRIEND, TEAM_ENEMY, TEAM_BACKGROUND, TEAM_BLOOD, TEAM_KATANA,
       TEAM_PUNCH, TEAM_BULLET, TEAM_DEBRIS };
enum { ACT_ATTACK, ACT_HURT, ACT_IDLE, ACT_WALK, ACT_RUN };

typedef struct Ent Ent;
struct Ent {
    int used, type, team, radius;
    int cx, cy;
    Rect bb; int hasbb;
    double dx, dy;
    int orientation, expiry;
    double theta;
    Ent *alias;                 /* emula o Point compartilhado do Java ate o 1o move */

    /* personagem */
    int isRolling, currentRollIdx;
    int isAttack, currentAttackIdx;
    int isFlipping, currentFlipIdx;
    int isRunning, isFacingLeft, run2IdleFlag;
    int isProtected;
    int isHurtGround, hurtGroundFrames, currentHurtGroundIdx;
    int viewRadius, isNoticed, atLeft, isChasing;
    int attackRadius, canAttack, totalPreAttackFrames, currentPreAttackFrame;
    int totalAttackIntervalFrames, currentAttackIntervalFrame;
    double xVelocity, xAccelerate, xSlowdownAccelerate;
    double yVelocity, maxXVelocity, maxYVelocity;
    int action;
    Ent *punch;                 /* inimigo */
    Ent *katana;                /* zero */
    int deathSoundPlayed;

    /* katana */
    int hitSlashMade, reflectMade;
    /* bala */
    int bvx, bvy, isReflected;
    /* porta */
    int isInfinite, enemyNumToSpawn, enemySpawned;
    /* debris */
    int index;
    int isSplatter, splatIdx, bgBloodIdx, bgBloodLeft, sp[6];
};

typedef struct {
    long score;
    int currentLevel;
    int enemyNums;
    int levelInited, levelCleared;
    int paused, slowmo;
    long frame;
    int viewX, viewY;
    int aim_show, aimx, aimy;   /* mira (deslocamento em unidades de mundo a partir do Zero) */
} GameState;

extern GameState G;
extern Ent *zero;

int  game_init(const char *data_dir);      /* 0 = ok */
void game_load_level(int level);           /* CommandCenter.initGame */
void game_frame(void);                     /* um passo de simulacao + desenho */

/* entrada */
int  game_input_blocked(void);             /* pausa / morto / fase limpa */
int  game_dead_screen(void);
void game_set_run(int dir);                /* -1 esq, +1 dir, 0 solto (chamar toda iteracao) */
void game_jump(void);
void game_down(void);                      /* rolar / cair mais rapido */
void game_attack(int ax, int ay);          /* vetor de mira relativo ao Zero */
void game_slowmo_start(unsigned now_ms);
void game_slowmo_end(void);
void game_slowmo_tick(unsigned now_ms);
void game_restart_level(void);
int  game_next_level(void);                /* 1 se avancou */
void game_prepare_level_select(void);
int  game_song_for_level(int level);

#endif
