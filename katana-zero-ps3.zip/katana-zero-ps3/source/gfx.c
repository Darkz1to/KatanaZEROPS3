#include "gfx.h"
#include "gen_assets.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

uint32_t fb[SCR_W * SCR_H];

static Img *imgs = NULL;
static uint32_t *pixpool = NULL;

static int rd_u16(const unsigned char *p) { return (p[0] << 8) | p[1]; }

int gfx_load_sprites(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return -1;

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);

    unsigned char *buf = (unsigned char *)malloc((size_t)size);
    if (!buf) { fclose(f); return -2; }
    if (fread(buf, 1, (size_t)size, f) != (size_t)size) { free(buf); fclose(f); return -3; }
    fclose(f);

    if (memcmp(buf, "KZSP", 4) != 0) { free(buf); return -4; }
    unsigned count = ((unsigned)buf[4] << 24) | (buf[5] << 16) | (buf[6] << 8) | buf[7];
    if ((int)count != SPRITE_TOTAL) { free(buf); return -5; }

    imgs = (Img *)calloc(count, sizeof(Img));
    /* pixels ocupam no maximo (size) bytes, o mesmo numero de uint32 */
    pixpool = (uint32_t *)malloc((size_t)size);
    if (!imgs || !pixpool) { free(buf); return -2; }

    size_t off = 8;
    uint32_t *dst = pixpool;
    for (unsigned i = 0; i < count; i++) {
        int w = rd_u16(buf + off), h = rd_u16(buf + off + 2);
        off += 4;
        imgs[i].w = w;
        imgs[i].h = h;
        imgs[i].px = dst;
        for (int k = 0; k < w * h; k++) {
            const unsigned char *p = buf + off + (size_t)k * 4;
            dst[k] = ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
        }
        dst += (size_t)w * h;
        off += (size_t)w * h * 4;
    }
    free(buf);
    return 0;
}

const Img *gfx_img(int set, int idx)
{
    if (set < 0 || set >= SET_TOTAL) return &imgs[0];
    int n = SET_COUNT[set];
    if (n <= 0) return &imgs[0];
    if (idx < 0) idx = 0;
    if (idx >= n) idx = n - 1;
    return &imgs[SET_FIRST[set] + idx];
}

void gfx_clear(uint32_t argb)
{
    for (int i = 0; i < SCR_W * SCR_H; i++) fb[i] = argb;
}

static inline uint32_t blend(uint32_t d, uint32_t s)
{
    unsigned a = s >> 24;
    if (a == 0) return d;
    if (a == 255) return s | 0xFF000000u;
    unsigned ia = 255 - a;
    unsigned t;
    unsigned r, g, b;
    t = ((s >> 16) & 255) * a + ((d >> 16) & 255) * ia + 128; r = (t + (t >> 8)) >> 8;
    t = ((s >> 8) & 255) * a + ((d >> 8) & 255) * ia + 128;   g = (t + (t >> 8)) >> 8;
    t = (s & 255) * a + (d & 255) * ia + 128;                  b = (t + (t >> 8)) >> 8;
    return 0xFF000000u | (r << 16) | (g << 8) | b;
}

void gfx_copy_full(const Img *im, int x, int y)
{
    for (int j = 0; j < im->h; j++) {
        int yy = y + j;
        if (yy < 0 || yy >= SCR_H) continue;
        int x0 = 0, x1 = im->w;
        if (x + x0 < 0) x0 = -x;
        if (x + x1 > SCR_W) x1 = SCR_W - x;
        if (x1 <= x0) continue;
        const uint32_t *s = im->px + j * im->w + x0;
        uint32_t *d = fb + yy * SCR_W + x + x0;
        for (int i = x0; i < x1; i++) *d++ = *s++ | 0xFF000000u;
    }
}

void gfx_blit(const Img *im, int x, int y)
{
    for (int j = 0; j < im->h; j++) {
        int yy = y + j;
        if (yy < 0 || yy >= SCR_H) continue;
        int x0 = 0, x1 = im->w;
        if (x + x0 < 0) x0 = -x;
        if (x + x1 > SCR_W) x1 = SCR_W - x;
        if (x1 <= x0) continue;
        const uint32_t *s = im->px + j * im->w + x0;
        uint32_t *d = fb + yy * SCR_W + x + x0;
        for (int i = x0; i < x1; i++, s++, d++) {
            uint32_t p = *s;
            if ((p >> 24) == 0) continue;
            *d = blend(*d, p);
        }
    }
}

void gfx_blit_flip(const Img *im, int x, int y)
{
    for (int j = 0; j < im->h; j++) {
        int yy = y + j;
        if (yy < 0 || yy >= SCR_H) continue;
        const uint32_t *row = im->px + j * im->w;
        for (int i = 0; i < im->w; i++) {
            int xx = x + i;
            if (xx < 0 || xx >= SCR_W) continue;
            uint32_t p = row[im->w - 1 - i];
            if ((p >> 24) == 0) continue;
            uint32_t *d = fb + yy * SCR_W + xx;
            *d = blend(*d, p);
        }
    }
}

/* Desenha 'im' girada em 'deg' graus ao redor do centro (cx,cy), no mesmo
 * sentido do AffineTransform.rotate do Java (eixo Y para baixo).
 * flip != 0 espelha a imagem em X antes de girar (como scale(-1,1)). */
void gfx_blit_rot(const Img *im, double cx, double cy, double deg, int flip)
{
    double th = deg * 3.14159265358979323846 / 180.0;
    double c = cos(th), s = sin(th);
    double hw = im->w * 0.5, hh = im->h * 0.5;
    int R = (int)ceil(sqrt(hw * hw + hh * hh)) + 1;
    int ix0 = (int)floor(cx) - R, iy0 = (int)floor(cy) - R;
    double fs = flip ? -1.0 : 1.0;

    for (int Y = iy0; Y <= iy0 + 2 * R; Y++) {
        if (Y < 0 || Y >= SCR_H) continue;
        for (int X = ix0; X <= ix0 + 2 * R; X++) {
            if (X < 0 || X >= SCR_W) continue;
            double dx = X + 0.5 - cx, dy = Y + 0.5 - cy;
            double ux = dx * c + dy * s;
            double uy = -dx * s + dy * c;
            int sx = (int)floor(hw + fs * ux);
            int sy = (int)floor(hh + uy);
            if (sx < 0 || sy < 0 || sx >= im->w || sy >= im->h) continue;
            uint32_t p = im->px[sy * im->w + sx];
            if ((p >> 24) == 0) continue;
            uint32_t *d = fb + Y * SCR_W + X;
            *d = blend(*d, p);
        }
    }
}

void gfx_fill_alpha(int x, int y, int w, int h, uint32_t argb)
{
    int x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y;
    int x1 = x + w > SCR_W ? SCR_W : x + w, y1 = y + h > SCR_H ? SCR_H : y + h;
    for (int j = y0; j < y1; j++) {
        uint32_t *d = fb + j * SCR_W + x0;
        for (int i = x0; i < x1; i++, d++) *d = blend(*d, argb);
    }
}

void gfx_frame_rect(int x, int y, int w, int h, int t, uint32_t argb)
{
    gfx_fill_alpha(x, y, w, t, argb);
    gfx_fill_alpha(x, y + h - t, w, t, argb);
    gfx_fill_alpha(x, y + t, t, h - 2 * t, argb);
    gfx_fill_alpha(x + w - t, y + t, t, h - 2 * t, argb);
}

/* ---- texto ---------------------------------------------------------------- */
int gfx_text_w(const char *s)
{
    int w = 0;
    for (; *s; s++) {
        int c = (unsigned char)*s;
        if (c < 32 || c > 126) c = '?';
        w += FONT_ADV[c - 32];
    }
    return w;
}

void gfx_text(int x, int y, const char *s, uint32_t argb)
{
    for (; *s; s++) {
        int c = (unsigned char)*s;
        if (c < 32 || c > 126) c = '?';
        const Img *g = gfx_img(SET_FONT, c - 32);
        for (int j = 0; j < g->h; j++) {
            int yy = y + j;
            if (yy < 0 || yy >= SCR_H) continue;
            for (int i = 0; i < g->w; i++) {
                int xx = x + i;
                if (xx < 0 || xx >= SCR_W) continue;
                unsigned a = g->px[j * g->w + i] >> 24;
                if (a == 0) continue;
                uint32_t *d = fb + yy * SCR_W + xx;
                *d = blend(*d, (argb & 0x00FFFFFFu) | (((a * (argb >> 24)) / 255) << 24));
            }
        }
        x += g->w;
    }
}

void gfx_text_center(int cx, int y, const char *s, uint32_t argb)
{
    gfx_text(cx - gfx_text_w(s) / 2, y, s, argb);
}
