/* Katana ZERO (clone) - port para PlayStation 3 (PSL1GHT + SDL2) */
#include <SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "gfx.h"
#include "game.h"
#include "audio.h"
#include "gen_assets.h"

#ifndef DATA_DIR
#define DATA_DIR "/dev_hdd0/game/KATANA001/USRDIR/data"
#endif

/* indices de botoes do driver joystick do SDL2 PSL1GHT */
enum { B_LEFT, B_DOWN, B_RIGHT, B_UP, B_START, B_R3, B_L3, B_SELECT,
       B_SQUARE, B_CROSS, B_CIRCLE, B_TRIANGLE, B_R1, B_L1, B_R2, B_L2, B_COUNT };
#define BIT(b) (1u << (b))

enum { ST_MENU, ST_LEVELS, ST_PLAY };

static const char *SONGS[6] = {
    "song_sneaky_driver.ogg", "song_slaughterhouse.ogg", "song_chinatown.ogg",
    "song_thirddistrict.ogg", "song_dragon.ogg", "song_rainonbrick.ogg"
};
static const char *LEVEL_NAMES[9] = {
    "Factory 1", "Factory 2", "Studio 1", "Studio 2", "Chinatown 1",
    "Chinatown 2", "Motel 1", "Motel 2", "Infinite"
};

static int state = ST_MENU, prev_state = -1;
static int selection = 0;
static int running = 1;

static SDL_Joystick *joy = NULL;
static unsigned btn = 0, btn_prev = 0;
static int ax_l[2], ax_r[2];          /* -32768..32767 */
static int stick_up_prev = 0, stick_down_prev = 0, stick_l_prev = 0, stick_r_prev = 0;

static void poll_pad(void)
{
    if (!joy && SDL_NumJoysticks() > 0) joy = SDL_JoystickOpen(0);
    btn_prev = btn;
    btn = 0;
    memset(ax_l, 0, sizeof(ax_l));
    memset(ax_r, 0, sizeof(ax_r));
    if (!joy) return;
    SDL_JoystickUpdate();
    for (int b = 0; b < B_COUNT; b++)
        if (SDL_JoystickGetButton(joy, b)) btn |= BIT(b);
    ax_l[0] = SDL_JoystickGetAxis(joy, 0);
    ax_l[1] = SDL_JoystickGetAxis(joy, 1);
    ax_r[0] = SDL_JoystickGetAxis(joy, 2);
    ax_r[1] = SDL_JoystickGetAxis(joy, 3);
}

static int pressed(int b) { return (btn & BIT(b)) && !(btn_prev & BIT(b)); }
static int held(int b)    { return (btn & BIT(b)) != 0; }
static int mag(const int *a) { return (int)sqrt((double)a[0] * a[0] + (double)a[1] * a[1]); }

#define DEAD   11000
#define ATKDEAD 18000
#define EDGE   22000

static void set_music(int idx) { music_play(SONGS[idx]); }

static void enter_state(int ns)
{
    int old = state;
    state = ns;
    if (ns == ST_LEVELS && old != ST_MENU) set_music(5);
    if (ns == ST_PLAY) {
        game_load_level(selection);
        set_music(game_song_for_level(G.currentLevel));
    }
}

/* ------------------------------------------------------------------ entrada */
static void input_menu(void)
{
    if (pressed(B_START) || pressed(B_CROSS)) {
        sfx_play("menu/sound_transition_begin");
        enter_state(ST_LEVELS);
    }
    if (pressed(B_SELECT)) running = 0;
}

static void move_selection(int d)
{
    selection = (selection + d + 9) % 9;
    sfx_play("menu/pause");
}

static void input_levels(void)
{
    int sl = ax_l[0] < -EDGE, sr = ax_l[0] > EDGE, su = ax_l[1] < -EDGE, sd = ax_l[1] > EDGE;
    int left  = pressed(B_LEFT)  || (sl && !stick_l_prev);
    int right = pressed(B_RIGHT) || (sr && !stick_r_prev);
    int up    = pressed(B_UP)    || (su && !stick_up_prev);
    int down  = pressed(B_DOWN)  || (sd && !stick_down_prev);
    stick_l_prev = sl; stick_r_prev = sr; stick_up_prev = su; stick_down_prev = sd;

    if (left) move_selection(-1);
    else if (right) move_selection(1);
    else if (up) {
        if (selection > 3 && selection < 8) selection -= 4;
        else if (selection < 4) selection = 8;
        else selection = 4;
        sfx_play("menu/pause");
    } else if (down) {
        if (selection < 5) selection += 4;
        else if (selection < 8) selection = 8;
        else selection = 0;
        sfx_play("menu/pause");
    }
    if (pressed(B_CROSS) || pressed(B_START)) {
        sfx_play("menu/rewind");
        enter_state(ST_PLAY);
    }
    if (pressed(B_SELECT)) running = 0;
}

static void input_play(unsigned now)
{
    int sl = ax_l[0] < -DEAD, sr = ax_l[0] > DEAD;
    int su = ax_l[1] < -EDGE, sd = ax_l[1] > EDGE;
    int stick_up_edge = su && !stick_up_prev;
    int stick_down_edge = sd && !stick_down_prev;
    stick_up_prev = su; stick_down_prev = sd;

    int down_edge = pressed(B_CIRCLE) || pressed(B_DOWN) || stick_down_edge;
    int blocked = game_input_blocked();

    if (pressed(B_START)) G.paused = !G.paused;
    blocked = game_input_blocked();

    if (blocked) {
        game_set_run(0);
        game_slowmo_end();
        if (down_edge) { game_restart_level(); return; }
        if (pressed(B_CROSS) && game_next_level()) {
            set_music(game_song_for_level(G.currentLevel));
            return;
        }
        if (pressed(B_TRIANGLE)) {
            game_prepare_level_select();
            state = ST_LEVELS;
            set_music(5);
            return;
        }
        if (pressed(B_SELECT)) running = 0;
        return;
    }

    /* movimento */
    int dir = 0;
    int l = held(B_LEFT) || sl, r = held(B_RIGHT) || sr;
    if (l && !r) dir = -1;
    else if (r && !l) dir = 1;
    else if (l && r) dir = zero->isFacingLeft ? -1 : 1;
    game_set_run(dir);

    if (pressed(B_CROSS) || pressed(B_UP) || stick_up_edge) game_jump();
    if (down_edge) game_down();

    /* mira: analogico direito, senao esquerdo, senao direcao que esta olhando */
    int rx = ax_r[0], ry = ax_r[1];
    G.aim_show = 0;
    int aimx = 0, aimy = 0, have_aim = 0;
    if (mag(ax_r) > DEAD) {
        double m = sqrt((double)rx * rx + (double)ry * ry);
        aimx = (int)(rx / m * 260.0);
        aimy = (int)(ry / m * 260.0);
        have_aim = 1;
        G.aim_show = 1; G.aimx = aimx; G.aimy = aimy;
    }
    if (pressed(B_SQUARE) || pressed(B_R1)) {
        int vx, vy;
        if (have_aim) { vx = aimx; vy = aimy; }
        else if (mag(ax_l) > ATKDEAD) {
            vx = ax_l[0] / 128; vy = ax_l[1] / 128;
        } else {
            vx = zero->isFacingLeft ? -100 : 100; vy = 0;
            if (held(B_UP)) vy = -100;
            if (held(B_LEFT)) vx = -100; else if (held(B_RIGHT)) vx = 100;
        }
        game_attack(vx, vy);
    }

    /* camera lenta */
    int slow_btn = held(B_L1) || held(B_L2) || held(B_R2);
    int slow_press = pressed(B_L1) || pressed(B_L2) || pressed(B_R2);
    if (slow_press) game_slowmo_start(now);
    if (!slow_btn) game_slowmo_end();
    game_slowmo_tick(now);
}

/* ------------------------------------------------------------------ telas */
static void draw_menu(void)
{
    const int y0 = -22;
    gfx_clear(0xFF000000u);
    gfx_copy_full(gfx_img(SET_MENU_TITLE, 0), 0, y0);
    gfx_blit(gfx_img(SET_MENU_LIGHT, 0), 0, y0);
    if (G.frame % 6 != 0) gfx_blit(gfx_img(SET_MENU_LIGHT, 1), 0, y0);
    if (G.frame % 10 < 5) gfx_blit(gfx_img(SET_MENU_LIGHT, 2), 0, y0);
    gfx_blit(gfx_img(SET_MENU_KATANA, 0), 0, y0);
    gfx_blit(gfx_img(SET_MENU_GRASS, 0), 0, y0);
    static int plant = 0;
    if (G.frame % 5 == 0) { plant++; if (plant >= 12) plant = 0; }
    gfx_blit(gfx_img(SET_MENU_PLANT, plant), 0, 150 + y0);
    gfx_blit(gfx_img(SET_MENU_FONT, 0), 0, y0);
    if ((G.frame / 15) % 2 == 0)
        gfx_text_center(SCR_W / 2, 318, "PRESS START", 0xFFFFFFFFu);
}

static void draw_levels(void)
{
    gfx_clear(0xFF000000u);
    for (int i = 0; i < 9; i++) {
        int cw, cx, cy;
        if (i < 8) { cw = 160; cx = (i % 4) * 160; cy = (i / 4) * 120; }
        else { cw = 640; cx = 0; cy = 240; }
        const Img *c = gfx_img(SET_COVER, i);
        int ix = cx + (cw - c->w) / 2, iy = cy + 3;
        gfx_copy_full(c, ix, iy);
        if (i == selection) gfx_frame_rect(ix - 3, iy - 3, c->w + 6, c->h + 6, 3, 0xFFFFFFFFu);
        gfx_text_center(cx + cw / 2, cy + 96, LEVEL_NAMES[i], i == selection ? 0xFFFFFFFFu : 0xFF909090u);
    }
}

/* ------------------------------------------------------------------ main */
int main(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *data = getenv("KZ_DATA");
    if (!data) data = DATA_DIR;

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_JOYSTICK) != 0) return 1;

    SDL_DisplayMode dm;
    int ow = 1280, oh = 720;
    if (SDL_GetCurrentDisplayMode(0, &dm) == 0 && dm.w > 0 && dm.h > 0) { ow = dm.w; oh = dm.h; }

    SDL_Window *win = SDL_CreateWindow("Katana ZERO", 0, 0, ow, oh, SDL_WINDOW_FULLSCREEN);
    if (!win) return 2;
    SDL_Renderer *ren = SDL_CreateRenderer(win, -1, 0);
    if (!ren) return 3;
    SDL_Texture *tex = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, SCR_W, SCR_H);
    if (!tex) return 4;
    SDL_GetRendererOutputSize(ren, &ow, &oh);
    SDL_ShowCursor(SDL_DISABLE);

    /* tela de carregamento simples */
    memset(fb, 0, sizeof(fb));
    SDL_UpdateTexture(tex, NULL, fb, SCR_W * 4);
    SDL_Rect dst = {0, 0, ow, oh};
    SDL_RenderCopy(ren, tex, NULL, &dst);
    SDL_RenderPresent(ren);

    int gr = game_init(data);
    if (gr != 0) {
        /* erro: mostra uma tela vermelha para facilitar o diagnostico */
        for (int i = 0; i < SCR_W * SCR_H; i++) fb[i] = 0xFF600000u;
        for (int f = 0; f < 600 && running; f++) {
            SDL_UpdateTexture(tex, NULL, fb, SCR_W * 4);
            SDL_RenderCopy(ren, tex, NULL, &dst);
            SDL_RenderPresent(ren);
        }
        return 5;
    }
    audio_init(data);
    set_music(5);

    unsigned next_tick = SDL_GetTicks();
    while (running) {
        SDL_Event ev;
        while (SDL_PollEvent(&ev))
            if (ev.type == SDL_QUIT) running = 0;

        poll_pad();
        unsigned now = SDL_GetTicks();

        if (state != prev_state) { prev_state = state; stick_l_prev = stick_r_prev = stick_up_prev = stick_down_prev = 1; }

        switch (state) {
        case ST_MENU:   input_menu(); break;
        case ST_LEVELS: input_levels(); break;
        case ST_PLAY:   input_play(now); break;
        }
        if (state != prev_state && state == ST_PLAY) prev_state = state;

        unsigned delay = (state == ST_PLAY && G.slowmo) ? 150 : 30;
        int stepped = 0;
        while (now >= next_tick) {
            switch (state) {
            case ST_MENU:   draw_menu(); G.frame++; break;
            case ST_LEVELS: draw_levels(); G.frame++; break;
            case ST_PLAY:   game_frame(); break;
            }
            stepped = 1;
            next_tick += delay;
            if (now > next_tick + 200) next_tick = now + delay;
        }
        if (stepped) SDL_UpdateTexture(tex, NULL, fb, SCR_W * 4);
        SDL_RenderCopy(ren, tex, NULL, &dst);
        SDL_RenderPresent(ren);
    }

    audio_shutdown();
    SDL_Quit();
    return 0;
}
