/* Katana ZERO (clone) - port para PlayStation 3 (PSL1GHT, sem SDL)
 *
 * Video : RSX direto (gcm), 2 buffers, flip sincronizado no vsync (60 Hz).
 * Entrada: libio (ioPad). Saida: callback do sysutil (botao PS / XMB).
 * Audio : libaudio, em audio.c.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
#include <unistd.h>
#include <stdint.h>

#include <ppu-types.h>
#include <sys/process.h>
#include <sysutil/sysutil.h>
#include <sysutil/video.h>
#include <rsx/rsx.h>
#include <rsx/gcm_sys.h>
#include <io/pad.h>

#include "gfx.h"
#include "game.h"
#include "audio.h"
#include "gen_assets.h"

#ifndef DATA_DIR
#define DATA_DIR "/dev_hdd0/game/KATANA001/USRDIR/data"
#endif
#define LOG_PATH "/dev_hdd0/tmp/katana_log.txt"

/* indices de botoes (mesma ordem usada pela logica de entrada abaixo) */
enum { B_LEFT, B_DOWN, B_RIGHT, B_UP, B_START, B_R3, B_L3, B_SELECT,
       B_SQUARE, B_CROSS, B_CIRCLE, B_TRIANGLE, B_R1, B_L1, B_R2, B_L2, B_COUNT };
#define BIT(b) (1u << (b))

enum { ST_MENU, ST_LEVELS, ST_PLAY };

static const char *SONGS[6] = {
    "song_sneaky_driver.ogg", "song_slaughterhouse.ogg", "song_chinatown.ogg",
    "song_thirddistrict.ogg", "song_dragon.ogg", "song_rainonbrick.ogg"
};
static const char *LEVEL_NAMES[9] = {
    "Factory 1", "Factory 2", "Studio 1", "Studio 2", "Chinatown 1",
    "Chinatown 2", "Motel 1", "Motel 2", "Infinite"
};

static int state = ST_MENU, prev_state = -1;
static int selection = 0;
static volatile int running = 1;

static unsigned btn = 0, btn_prev = 0;
static int ax_l[2], ax_r[2];          /* -32768..32767 */
static int stick_up_prev = 0, stick_down_prev = 0, stick_l_prev = 0, stick_r_prev = 0;

/* ------------------------------------------------------------------ tempo */
#define TB_HZ 79800000ULL             /* timebase do Cell */
static inline uint64_t tb_now(void) { uint64_t t; __asm__ volatile("mftb %0" : "=r"(t)); return t; }
static unsigned ms_now(void) { return (unsigned)((tb_now() * 1000ULL) / TB_HZ); }
static unsigned us_now(void) { return (unsigned)((tb_now() * 1000000ULL) / TB_HZ); }

/* ------------------------------------------------------------------ sistema */
static void sysutil_cb(u64 status, u64 param, void *usrdata)
{
    (void)param; (void)usrdata;
    if (status == SYSUTIL_EXIT_GAME) running = 0;   /* botao PS -> Sair do jogo */
}

/* ------------------------------------------------------------------ video */
#define CB_SIZE   0x100000
#define HOST_SIZE (4 * 1024 * 1024)
#define GCM_LABEL_INDEX 255

static gcmContextData *ctx = NULL;
static u32 vid_w, vid_h, vid_pitch;
static u32 *vbuf[2];
static u32 voff[2];
static int shown = 0;                 /* buffer que esta na tela (ou ja foi enfileirado) */
static int first_flip = 1;
static int scale = 1;                 /* escala inteira do 640x360 */
static int ox = 0, oy = 0;            /* margens (letterbox) */
static unsigned long flip_timeouts = 0;
static u32 label_val = 1;

static void wait_rsx_idle(void)
{
    rsxSetWriteBackendLabel(ctx, GCM_LABEL_INDEX, label_val);
    rsxSetWaitLabel(ctx, GCM_LABEL_INDEX, label_val);
    label_val++;
    rsxSetWriteBackendLabel(ctx, GCM_LABEL_INDEX, label_val);
    rsxFlushBuffer(ctx);
    unsigned t0 = ms_now();
    while (*(volatile u32 *)gcmGetLabelAddress(GCM_LABEL_INDEX) != label_val) {
        usleep(30);
        if (ms_now() - t0 > 1000) break;       /* nunca trava aqui */
    }
    label_val++;
}

/* espera o flip anterior terminar, no maximo 300 ms */
static void wait_flip(void)
{
    unsigned t0 = ms_now();
    while (gcmGetFlipStatus() != 0) {
        usleep(200);
        if (ms_now() - t0 > 300) { flip_timeouts++; break; }
    }
    gcmResetFlipStatus();
}

static void flip_to(int id)
{
    if (first_flip) { first_flip = 0; gcmResetFlipStatus(); }
    else wait_flip();
    if (gcmSetFlip(ctx, (u8)id) == 0) {
        rsxFlushBuffer(ctx);
        gcmSetWaitFlip(ctx);
    }
    shown = id;
}

static int video_init(void)
{
    void *host = memalign(1024 * 1024, HOST_SIZE);
    if (!host) return -1;
    if (rsxInit(&ctx, CB_SIZE, HOST_SIZE, host) != 0 || !ctx) return -2;

    videoState vs;
    if (videoGetState(0, 0, &vs) != 0) return -3;
    videoResolution res;
    if (videoGetResolution(vs.displayMode.resolution, &res) != 0) return -4;

    videoConfiguration vc;
    memset(&vc, 0, sizeof(vc));
    vc.resolution = vs.displayMode.resolution;
    vc.format = VIDEO_BUFFER_FORMAT_XRGB;
    vc.pitch = res.width * sizeof(u32);
    vc.aspect = vs.displayMode.aspect;
    wait_rsx_idle();
    if (videoConfigure(0, &vc, NULL, 0) != 0) return -5;
    if (videoGetState(0, 0, &vs) != 0) return -6;

    gcmSetFlipMode(GCM_FLIP_VSYNC);

    vid_w = res.width;
    vid_h = res.height;
    vid_pitch = res.width * sizeof(u32);
    for (int i = 0; i < 2; i++) {
        vbuf[i] = (u32 *)rsxMemalign(64, vid_pitch * vid_h);
        if (!vbuf[i]) return -7;
        if (rsxAddressToOffset(vbuf[i], &voff[i]) != 0) return -8;
        if (gcmSetDisplayBuffer(i, voff[i], vid_pitch, vid_w, vid_h) != 0) return -9;
        memset(vbuf[i], 0, vid_pitch * vid_h);
    }
    gcmResetFlipStatus();

    /* escala inteira: 720p = 2x, 1080p = 3x; outras resolucoes ficam com barras pretas */
    int sx = (int)vid_w / SCR_W, sy = (int)vid_h / SCR_H;
    scale = sx < sy ? sx : sy;
    if (scale < 1) scale = 1;
    ox = ((int)vid_w - SCR_W * scale) / 2;
    oy = ((int)vid_h - SCR_H * scale) / 2;
    if (ox < 0) ox = 0;
    if (oy < 0) oy = 0;
    ox &= ~1;                                   /* alinhado em 8 bytes */

    shown = 0;
    flip_to(0);                                 /* mostra preto */
    return 0;
}

/* copia 'fb' (640x360) escalado para o buffer que NAO esta na tela */
static void blit_to_back(void)
{
    static uint32_t row[SCR_W * 4];             /* ate 4x */
    int back = shown ^ 1;
    u32 *dst = vbuf[back];
    int pitch_px = (int)(vid_pitch / 4);
    int cols = SCR_W * scale;
    if (scale > 4 || cols > (int)vid_w) return; /* seguranca */

    for (int y = 0; y < SCR_H; y++) {
        int rows_y = oy + y * scale;
        if (rows_y + scale > (int)vid_h) break;
        const uint32_t *src = fb + y * SCR_W;
        if (scale == 1) {
            for (int x = 0; x < SCR_W; x++) row[x] = src[x];
        } else if (scale == 2) {
            for (int x = 0; x < SCR_W; x++) { uint32_t p = src[x]; row[2 * x] = p; row[2 * x + 1] = p; }
        } else {
            for (int x = 0; x < SCR_W; x++) {
                uint32_t p = src[x];
                for (int k = 0; k < scale; k++) row[x * scale + k] = p;
            }
        }
        for (int k = 0; k < scale; k++) {
            u64 *d = (u64 *)(void *)(dst + (rows_y + k) * pitch_px + ox);
            const u64 *s = (const u64 *)(const void *)row;
            for (int i = 0; i < cols / 2; i++) d[i] = s[i];
        }
    }
}

static void video_shutdown(void)
{
    wait_rsx_idle();
    gcmSetWaitFlip(ctx);
    for (int i = 0; i < 2; i++) if (vbuf[i]) rsxFree(vbuf[i]);
    rsxFinish(ctx, 1);
}

/* ------------------------------------------------------------------ controle */
static padInfo pinfo;
static padData pdata;

static void poll_pad(void)
{
    btn_prev = btn;
    btn = 0;
    memset(ax_l, 0, sizeof(ax_l));
    memset(ax_r, 0, sizeof(ax_r));

    ioPadGetInfo(&pinfo);
    if (!pinfo.status[0]) { memset(&pdata, 0, sizeof(pdata)); return; }

    /* o pad atualiza em ritmo proprio: se nao houver dado novo (len == 0) o
     * estado anterior continua valendo. Zerar aqui fazia o personagem
     * "soltar" o analogico por 1 frame e parar de correr. */
    padData tmp;
    if (ioPadGetData(0, &tmp) == 0 && tmp.len > 0) pdata = tmp;
    else if (pdata.len == 0) return;      /* nunca recebeu dado */

    if (pdata.BTN_LEFT)     btn |= BIT(B_LEFT);
    if (pdata.BTN_DOWN)     btn |= BIT(B_DOWN);
    if (pdata.BTN_RIGHT)    btn |= BIT(B_RIGHT);
    if (pdata.BTN_UP)       btn |= BIT(B_UP);
    if (pdata.BTN_START)    btn |= BIT(B_START);
    if (pdata.BTN_R3)       btn |= BIT(B_R3);
    if (pdata.BTN_L3)       btn |= BIT(B_L3);
    if (pdata.BTN_SELECT)   btn |= BIT(B_SELECT);
    if (pdata.BTN_SQUARE)   btn |= BIT(B_SQUARE);
    if (pdata.BTN_CROSS)    btn |= BIT(B_CROSS);
    if (pdata.BTN_CIRCLE)   btn |= BIT(B_CIRCLE);
    if (pdata.BTN_TRIANGLE) btn |= BIT(B_TRIANGLE);
    if (pdata.BTN_R1)       btn |= BIT(B_R1);
    if (pdata.BTN_L1)       btn |= BIT(B_L1);
    if (pdata.BTN_R2)       btn |= BIT(B_R2);
    if (pdata.BTN_L2)       btn |= BIT(B_L2);

    /* 0..255 (128 = centro) -> -32768..32767; 0 em cima, 255 embaixo */
    ax_l[0] = ((int)pdata.ANA_L_H - 128) * 256;
    ax_l[1] = ((int)pdata.ANA_L_V - 128) * 256;
    ax_r[0] = ((int)pdata.ANA_R_H - 128) * 256;
    ax_r[1] = ((int)pdata.ANA_R_V - 128) * 256;
}

static int pressed(int b) { return (btn & BIT(b)) && !(btn_prev & BIT(b)); }
static int held(int b)    { return (btn & BIT(b)) != 0; }
static int mag(const int *a) { return (int)sqrt((double)a[0] * a[0] + (double)a[1] * a[1]); }

#define DEAD   11000
#define ATKDEAD 18000
#define EDGE   22000

static void set_music(int idx) { music_play(SONGS[idx]); }

static void enter_state(int ns)
{
    int old = state;
    state = ns;
    if (ns == ST_LEVELS && old != ST_MENU) set_music(5);
    if (ns == ST_PLAY) {
        game_load_level(selection);
        set_music(game_song_for_level(G.currentLevel));
    }
}

/* ------------------------------------------------------------------ entrada */
static void input_menu(void)
{
    if (pressed(B_START) || pressed(B_CROSS)) {
        sfx_play("menu/sound_transition_begin");
        enter_state(ST_LEVELS);
    }
    if (pressed(B_SELECT)) running = 0;
}

static void move_selection(int d)
{
    selection = (selection + d + 9) % 9;
    sfx_play("menu/pause");
}

static void input_levels(void)
{
    int sl = ax_l[0] < -EDGE, sr = ax_l[0] > EDGE, su = ax_l[1] < -EDGE, sd = ax_l[1] > EDGE;
    int left  = pressed(B_LEFT)  || (sl && !stick_l_prev);
    int right = pressed(B_RIGHT) || (sr && !stick_r_prev);
    int up    = pressed(B_UP)    || (su && !stick_up_prev);
    int down  = pressed(B_DOWN)  || (sd && !stick_down_prev);
    stick_l_prev = sl; stick_r_prev = sr; stick_up_prev = su; stick_down_prev = sd;

    if (left) move_selection(-1);
    else if (right) move_selection(1);
    else if (up) {
        if (selection > 3 && selection < 8) selection -= 4;
        else if (selection < 4) selection = 8;
        else selection = 4;
        sfx_play("menu/pause");
    } else if (down) {
        if (selection < 5) selection += 4;
        else if (selection < 8) selection = 8;
        else selection = 0;
        sfx_play("menu/pause");
    }
    if (pressed(B_CROSS) || pressed(B_START)) {
        sfx_play("menu/rewind");
        enter_state(ST_PLAY);
    }
    if (pressed(B_SELECT)) running = 0;
}

static void input_play(unsigned now)
{
    int sl = ax_l[0] < -DEAD, sr = ax_l[0] > DEAD;
    int su = ax_l[1] < -EDGE, sd = ax_l[1] > EDGE;
    int stick_up_edge = su && !stick_up_prev;
    int stick_down_edge = sd && !stick_down_prev;
    stick_up_prev = su; stick_down_prev = sd;

    int down_edge = pressed(B_CIRCLE) || pressed(B_DOWN) || stick_down_edge;
    int blocked = game_input_blocked();

    if (pressed(B_START)) G.paused = !G.paused;
    blocked = game_input_blocked();

    if (blocked) {
        game_set_run(0);
        game_slowmo_end();
        if (down_edge) { game_restart_level(); return; }
        if (pressed(B_CROSS) && game_next_level()) {
            set_music(game_song_for_level(G.currentLevel));
            return;
        }
        if (pressed(B_TRIANGLE)) {
            game_prepare_level_select();
            state = ST_LEVELS;
            set_music(5);
            return;
        }
        if (pressed(B_SELECT)) running = 0;
        return;
    }

    /* movimento */
    int dir = 0;
    int l = held(B_LEFT) || sl, r = held(B_RIGHT) || sr;
    if (l && !r) dir = -1;
    else if (r && !l) dir = 1;
    else if (l && r) dir = zero->isFacingLeft ? -1 : 1;
    game_set_run(dir);

    if (pressed(B_CROSS) || pressed(B_UP) || stick_up_edge) game_jump();
    if (down_edge) game_down();

    /* mira: analogico direito, senao esquerdo, senao direcao que esta olhando */
    int rx = ax_r[0], ry = ax_r[1];
    G.aim_show = 0;
    int aimx = 0, aimy = 0, have_aim = 0;
    if (mag(ax_r) > DEAD) {
        double m = sqrt((double)rx * rx + (double)ry * ry);
        aimx = (int)(rx / m * 260.0);
        aimy = (int)(ry / m * 260.0);
        have_aim = 1;
        G.aim_show = 1; G.aimx = aimx; G.aimy = aimy;
    }
    if (pressed(B_SQUARE) || pressed(B_R1)) {
        int vx, vy;
        if (have_aim) { vx = aimx; vy = aimy; }
        else if (mag(ax_l) > ATKDEAD) {
            vx = ax_l[0] / 128; vy = ax_l[1] / 128;
        } else {
            vx = zero->isFacingLeft ? -100 : 100; vy = 0;
            if (held(B_UP)) vy = -100;
            if (held(B_LEFT)) vx = -100; else if (held(B_RIGHT)) vx = 100;
        }
        game_attack(vx, vy);
    }

    /* camera lenta */
    int slow_btn = held(B_L1) || held(B_L2) || held(B_R2);
    int slow_press = pressed(B_L1) || pressed(B_L2) || pressed(B_R2);
    if (slow_press) game_slowmo_start(now);
    if (!slow_btn) game_slowmo_end();
    game_slowmo_tick(now);
}

/* ------------------------------------------------------------------ telas */
static void draw_menu(void)
{
    const int y0 = -22;
    gfx_clear(0xFF000000u);
    gfx_copy_full(gfx_img(SET_MENU_TITLE, 0), 0, y0);
    gfx_blit(gfx_img(SET_MENU_LIGHT, 0), 0, y0);
    if (G.frame % 6 != 0) gfx_blit(gfx_img(SET_MENU_LIGHT, 1), 0, y0);
    if (G.frame % 10 < 5) gfx_blit(gfx_img(SET_MENU_LIGHT, 2), 0, y0);
    gfx_blit(gfx_img(SET_MENU_KATANA, 0), 0, y0);
    gfx_blit(gfx_img(SET_MENU_GRASS, 0), 0, y0);
    static int plant = 0;
    if (G.frame % 5 == 0) { plant++; if (plant >= 12) plant = 0; }
    gfx_blit(gfx_img(SET_MENU_PLANT, plant), 0, 150 + y0);
    gfx_blit(gfx_img(SET_MENU_FONT, 0), 0, y0);
    if ((G.frame / 15) % 2 == 0)
        gfx_text_center(SCR_W / 2, 318, "PRESS START", 0xFFFFFFFFu);
}

static void draw_levels(void)
{
    gfx_clear(0xFF000000u);
    for (int i = 0; i < 9; i++) {
        int cw, cx, cy;
        if (i < 8) { cw = 160; cx = (i % 4) * 160; cy = (i / 4) * 120; }
        else { cw = 640; cx = 0; cy = 240; }
        const Img *c = gfx_img(SET_COVER, i);
        int ix = cx + (cw - c->w) / 2, iy = cy + 3;
        gfx_copy_full(c, ix, iy);
        if (i == selection) gfx_frame_rect(ix - 3, iy - 3, c->w + 6, c->h + 6, 3, 0xFFFFFFFFu);
        gfx_text_center(cx + cw / 2, cy + 96, LEVEL_NAMES[i], i == selection ? 0xFFFFFFFFu : 0xFF909090u);
    }
}

/* ------------------------------------------------------------------ main */
#define SIM_MS      30                /* passo da simulacao (o do jogo original) */
#define SLOWMO_MS   150

int main(int argc, char **argv)
{
    (void)argc; (void)argv;
    const char *data = getenv("KZ_DATA");
    if (!data) data = DATA_DIR;

    FILE *logf = fopen(LOG_PATH, "w");
    #define LOG(...) do { if (logf) { fprintf(logf, __VA_ARGS__); fflush(logf); } } while (0)
    LOG("katana: inicio\n");

    sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, sysutil_cb, NULL);
    ioPadInit(7);

    int vr = video_init();
    LOG("video_init=%d  %ux%u  escala=%d  ox=%d oy=%d\n", vr, vid_w, vid_h, scale, ox, oy);
    if (vr != 0) return 1;

    /* tela de carregamento (preto) ja esta na tela */
    int gr = game_init(data);
    LOG("game_init=%d\n", gr);
    if (gr != 0) {
        /* erro: tela vermelha por ~10 s para facilitar o diagnostico */
        for (int i = 0; i < SCR_W * SCR_H; i++) fb[i] = 0xFF600000u;
        for (int f = 0; f < 600 && running; f++) {
            sysUtilCheckCallback();
            if (f % 30 == 0) blit_to_back();
            flip_to(f % 30 == 0 ? shown ^ 1 : shown);
        }
        return 5;
    }
    int ar = audio_init(data);
    LOG("audio_init=%d\n", ar);
    set_music(5);

    unsigned long iter = 0, sec_flips = 0, sec_ticks = 0;
    unsigned worst_copy_us = 0, worst_loop_us = 0;
    unsigned next_tick = ms_now();
    unsigned last_log = ms_now(), last_loop = us_now();

    while (running) {
        sysUtilCheckCallback();
        poll_pad();
        unsigned now = ms_now();

        if (state != prev_state) { prev_state = state; stick_l_prev = stick_r_prev = stick_up_prev = stick_down_prev = 1; }

        switch (state) {
        case ST_MENU:   input_menu(); break;
        case ST_LEVELS: input_levels(); break;
        case ST_PLAY:   input_play(now); break;
        }
        if (state != prev_state && state == ST_PLAY) prev_state = state;

        unsigned delay = (state == ST_PLAY && G.slowmo) ? SLOWMO_MS : SIM_MS;
        int stepped = 0;
        while (now >= next_tick) {
            switch (state) {
            case ST_MENU:   draw_menu(); G.frame++; break;
            case ST_LEVELS: draw_levels(); G.frame++; break;
            case ST_PLAY:   game_frame(); break;
            }
            stepped = 1;
            sec_ticks++;
            next_tick += delay;
            if (now > next_tick + 200) next_tick = now + delay;
        }

        /* o jogo so produz imagem nova a cada passo; nos outros vsyncs o mesmo
         * buffer e reapresentado (sem custo de copia), mantendo 60 flips/s */
        int target = shown;
        if (stepped) {
            unsigned c0 = us_now();
            blit_to_back();
            unsigned cu = us_now() - c0;
            if (cu > worst_copy_us) worst_copy_us = cu;
            target = shown ^ 1;
        }
        flip_to(target);
        sec_flips++;
        iter++;

        unsigned tu = us_now();
        if (tu - last_loop > worst_loop_us) worst_loop_us = tu - last_loop;
        last_loop = tu;

        unsigned t = ms_now();
        if (t - last_log >= 1000) {
            struct mallinfo mi = mallinfo();
            LOG("t=%u st=%d fps=%lu ticks=%lu flip_timeouts=%lu worst_loop=%.1fms worst_copy=%.1fms heap=%dKB\n",
                t, state, sec_flips, sec_ticks, flip_timeouts,
                worst_loop_us / 1000.0, worst_copy_us / 1000.0, (int)(mi.uordblks / 1024));
            sec_flips = sec_ticks = 0;
            worst_copy_us = worst_loop_us = 0;
            last_log = t;
        }
    }

    LOG("saindo\n");
    audio_shutdown();
    video_shutdown();
    ioPadEnd();
    sysUtilUnregisterCallback(SYSUTIL_EVENT_SLOT0);
    if (logf) fclose(logf);
    return 0;
}
