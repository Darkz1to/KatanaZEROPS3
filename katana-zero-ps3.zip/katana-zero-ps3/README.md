# Katana ZERO (clone) para PS3

Port em C (PSL1GHT nativo: RSX + libio + libaudio, sem SDL) do clone Java de Katana ZERO.

## Controles
| Acao | Botao |
|---|---|
| Andar | Analogico esquerdo / direcional |
| Pular / pular da parede | X (ou direcional cima) |
| Rolar (invulneravel) / cair rapido no ar | O (ou direcional baixo) |
| Atacar | Quadrado ou R1 |
| Mira do ataque | Analogico direito (senao, direcao do analogico esquerdo, senao para onde olha) |
| Camera lenta (segurar, max. 5 s) | L1 / L2 / R2 |
| Pausar | START |
| Reiniciar fase (morto/pausado/fase limpa) | O |
| Proxima fase (fase limpa) | X |
| Selecao de fases | Triangulo |
| Sair (menus/pausa) | SELECT (ou botao PS) |

## Compilar
1. `python3 tools/prep_assets.py <katana-zero-master>/src/main/resources`  (opcional: os assets ja vem convertidos)
2. `make -f Makefile.ps3 katana.pkg`  (so precisa do PSL1GHT) ou use o workflow do GitHub.

`tests/sim.c` roda a simulacao no PC sem janela e sem SDL (`gcc tests/sim.c tests/audio_stub.c source/game.c source/gfx.c -lm`).

## Log
O jogo grava `/dev_hdd0/tmp/katana_log.txt` a cada segundo: `fps` (flips por segundo), `ticks` (passos de simulacao), `flip_timeouts`, pior tempo de laco e de copia.
