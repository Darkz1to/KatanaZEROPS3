# Katana ZERO (clone) para PS3

Port em C (PSL1GHT + SDL2) do clone Java de Katana ZERO.

## Controles
| Acao | Botao |
|---|---|
| Andar | Analogico esquerdo / direcional |
| Pular / pular da parede | X (ou direcional cima) |
| Rolar (invulneravel) / cair rapido no ar | O (ou direcional baixo) |
| Atacar | Quadrado ou R1 |
| Mira do ataque | Analogico direito (senao, direcao do analogico esquerdo, senao para onde olha) |
| Camera lenta (segurar, max. 5 s) | L1 / L2 / R2 |
| Pausar | START |
| Reiniciar fase (morto/pausado/fase limpa) | O |
| Proxima fase (fase limpa) | X |
| Selecao de fases | Triangulo |
| Sair (menus/pausa) | SELECT (ou botao PS) |

## Compilar
1. `python3 tools/prep_assets.py <katana-zero-master>/src/main/resources`  (opcional: os assets ja vem convertidos)
2. `make -f Makefile.ps3 katana.pkg`  (com PSL1GHT + SDL2 instalados) ou use o workflow do GitHub.

`tests/sim.c` roda a simulacao no PC sem janela (`gcc tests/sim.c source/game.c source/gfx.c source/audio.c $(sdl2-config --cflags --libs) -lm`).
