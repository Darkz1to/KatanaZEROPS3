/* Audio falso para o teste no PC: so cumpre a interface de audio.h. */
#include "../source/audio.h"
int  audio_init(const char *d) { (void)d; return 0; }
void audio_shutdown(void) {}
int  sfx_play(const char *n) { (void)n; return 1; }
void sfx_playf(const char *f, int n) { (void)f; (void)n; }
void sfx_stop(int h) { (void)h; }
void music_play(const char *f) { (void)f; }
