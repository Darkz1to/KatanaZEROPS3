/* Teste headless no PC: roda a simulacao e grava quadros PPM. */
#include <stdio.h>
#include <stdlib.h>
#include "../source/gfx.h"
#include "../source/game.h"
#include "../source/audio.h"

static void dump(const char *name)
{
    FILE *f = fopen(name, "wb");
    fprintf(f, "P6\n%d %d\n255\n", SCR_W, SCR_H);
    for (int i = 0; i < SCR_W * SCR_H; i++) {
        uint32_t p = fb[i];
        fputc((p >> 16) & 255, f); fputc((p >> 8) & 255, f); fputc(p & 255, f);
    }
    fclose(f);
}

int main(int argc, char **argv)
{
    const char *d = argc > 1 ? argv[1] : "pkgfiles/USRDIR/data";
    int lvl = argc > 2 ? atoi(argv[2]) : 0;
    if (game_init(d)) { printf("game_init falhou\n"); return 1; }
    audio_init(d);
    game_load_level(lvl);
    for (int f = 0; f < 900; f++) {
        int dir = (f / 60) % 2 ? -1 : 1;
        if (f > 20) game_set_run(dir);
        if (f % 90 == 30) game_jump();
        if (f % 70 == 10) game_attack(dir * 100, 0);
        if (f % 200 == 150) game_down();
        if (f == 300) game_slowmo_start(0);
        if (f == 420) game_slowmo_end();
        game_frame();
        if (f == 5 || f == 120 || f == 400 || f == 899) {
            char n[64]; snprintf(n, sizeof n, "/tmp/frame_%d.ppm", f); dump(n);
        }
        if (game_input_blocked() && f % 50 == 0) { printf("bloqueado f=%d dead=%d\n", f, game_dead_screen()); game_restart_level(); }
    }
    printf("ok score=%ld enemies=%d frame=%ld\n", G.score, G.enemyNums, G.frame);
    return 0;
}
