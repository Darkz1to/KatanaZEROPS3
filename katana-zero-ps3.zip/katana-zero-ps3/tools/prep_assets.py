#!/usr/bin/env python3
"""
Converte os assets do projeto Java original (katana-zero-master) para o
formato usado pela versao PS3.

Uso:  python3 tools/prep_assets.py <pasta src/main/resources do projeto original>

Gera (dentro de katana-zero-ps3/):
  pkgfiles/USRDIR/data/sprites.bin   todos os sprites ja em ARGB (big-endian)
  pkgfiles/USRDIR/data/sfx.bin       efeitos sonoros, PCM s16 mono 48 kHz (big-endian)
  pkgfiles/USRDIR/data/music/*.ogg   musicas em Ogg Vorbis 48 kHz
  pkgfiles/USRDIR/data/maps/*.csv    mapas das fases
  pkgfiles/ICON0.PNG                 icone do jogo no XMB
  source/gen_assets.h                tabela de ids dos sprites / fonte

Requer: python3, Pillow, numpy, ffmpeg (com libvorbis).
"""
import os, sys, struct, subprocess, glob
from PIL import Image, ImageDraw, ImageFont
import numpy as np

SRC = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "katana-zero-master/src/main/resources")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "pkgfiles", "USRDIR", "data")
os.makedirs(os.path.join(DATA, "music"), exist_ok=True)
os.makedirs(os.path.join(DATA, "maps"), exist_ok=True)

IMG = os.path.join(SRC, "imgs")

# A tela do jogo original era 1080x684. No PS3 o jogo renderiza em 640x360
# (escalado por hardware para 720p/1080p). Os sprites ja eram desenhados com
# zoom 2x no original, entao no buffer de 640x360 eles ficam 1:1.
SCR_W, SCR_H = 640, 360
BG_SCALE = 640.0 / 1080.0          # fundos / menu
CROP_Y = 22                          # 405 -> 360 (corta o excesso)

sets = []          # (nome, [PIL.Image RGBA])


def load(p):
    return Image.open(p).convert("RGBA")


def add(name, paths, scale=None, resample=Image.NEAREST):
    ims = []
    for p in paths:
        im = load(p)
        if scale is not None:
            w = max(1, int(round(im.width * scale)))
            h = max(1, int(round(im.height * scale)))
            im = im.resize((w, h), resample)
        ims.append(im)
    sets.append((name, ims))


def seq(pattern, n):
    return [os.path.join(IMG, pattern % i) for i in range(n)]


Z = "ZeroSprites/"
add("ZERO_STAND",     seq(Z + "stand/spr_idle_%d.png", 11))
add("ZERO_RUN",       seq(Z + "run/spr_run_%d.png", 10))
add("ZERO_RUN2IDLE",  seq(Z + "run/spr_run_to_idle_%d.png", 5))
add("ZERO_JUMP",      seq(Z + "jump/spr_jump_%d.png", 4))
add("ZERO_FALL",      seq(Z + "fall/spr_fall_%d.png", 4))
add("ZERO_ROLL",      seq(Z + "roll/spr_roll_%d.png", 7))
add("ZERO_ATTACK",    seq(Z + "attack/spr_attack_%d.png", 7))
add("ZERO_FLIP",      seq(Z + "flip/spr_flip_%d.png", 11))
add("ZERO_WALLSLIDE", [os.path.join(IMG, Z + "wallSlide/spr_wallSlide_0.png")])
add("ZERO_HURT",      seq(Z + "hurt/spr_hurtground_%d.png", 6))
add("FX_SLASH",       seq(Z + "normalSlash/spr_slash_%d.png", 5))
add("FX_HITSLASH",    seq(Z + "hitSlash/%d.png", 4))
add("FX_JUMPCLOUD",   seq(Z + "jump/JumpCloud/spr_jumpcloud_%d.png", 4))
add("FX_BULLETREFLECT", seq(Z + "bulletReflect/%d.png", 5))

add("GRUNT_IDLE",   seq("Grunt/spr_grunt_idle/%d.png", 8))
add("GRUNT_HURT",   seq("Grunt/spr_grunt_hurtground/%d.png", 16))
add("GRUNT_WALK",   seq("Grunt/spr_grunt_walk/%d.png", 10))
add("GRUNT_RUN",    seq("Grunt/spr_grunt_run/%d.png", 10))
add("GRUNT_ATTACK", seq("Grunt/spr_grunt_attack/%d.png", 8))

add("POMP_IDLE",   seq("Pomp/spr_pomp_idle/%d.png", 8))
add("POMP_HURT",   seq("Pomp/spr_pomp_hurtground/%d.png", 15))
add("POMP_WALK",   seq("Pomp/spr_pomp_walk/%d.png", 10))
add("POMP_RUN",    seq("Pomp/spr_pomp_run/%d.png", 10))
add("POMP_ATTACK", seq("Pomp/spr_pomp_attack/%d.png", 6))

add("GANG_IDLE", seq("Gangster/spr_gangster_idle/%d.png", 8))
add("GANG_HURT", seq("Gangster/spr_gangster_hurtground/%d.png", 14))
add("GANG_WALK", seq("Gangster/spr_gangster_walk/%d.png", 8))
add("GANG_RUN",  seq("Gangster/spr_gangster_run/%d.png", 10))

add("SHLD_IDLE", seq("ShieldCop/spr_shieldcop_idle/%d.png", 6))
add("SHLD_HURT", seq("ShieldCop/spr_shieldcop_hurtground/%d.png", 15))
add("SHLD_WALK", seq("ShieldCop/spr_shieldcop_walk/%d.png", 10))
add("SHLD_RUN",  seq("ShieldCop/spr_shieldcop_run/%d.png", 10))

add("BLOOD_BG", seq("Blood/bg_blood/%d.png", 9))
# o original desenha o respingo com zoom 3x (= 1.5x no nosso buffer)
for d in range(16):
    add("BLOOD_SPLAT_%d" % d,
        [os.path.join(IMG, "Blood/spr_bloodsplatter_dir/%d_%d.png" % (d, j + 1)) for j in range(3)],
        scale=1.5)

add("BRICK",  [os.path.join(IMG, "Bricks/floor/102.png")])
add("DOOR",   [os.path.join(IMG, "door.png")])
add("BULLET", [os.path.join(IMG, "bullet.png")])
add("CURSOR", [os.path.join(IMG, "Cursor/0.png")])


def bg_layer(path):
    im = load(path)
    return im.resize((640, int(round(im.height * BG_SCALE))), Image.LANCZOS)


def bg_cropped(path):
    im = bg_layer(path)
    return im.crop((0, CROP_Y, 640, CROP_Y + SCR_H))


sets.append(("BG", [bg_cropped(os.path.join(IMG, "Levels/bgs/%d.jpg" % i)) for i in range(9)]))
sets.append(("COVER", [load(os.path.join(IMG, "Levels/covers/%d.png" % i)).resize(
    (int(round(200 * BG_SCALE)), int(round(150 * BG_SCALE))), Image.LANCZOS) for i in range(9)]))

M = os.path.join(IMG, "Menu/")
sets.append(("MENU_TITLE",  [bg_layer(M + "title.jpg")]))
sets.append(("MENU_LIGHT",  [bg_layer(M + "light_%d.png" % i) for i in range(3)]))
sets.append(("MENU_KATANA", [bg_layer(M + "title_katana.png")]))
sets.append(("MENU_GRASS",  [bg_layer(M + "title_grass.png")]))
sets.append(("MENU_PLANT",  [bg_layer(M + "plant_%d.png" % i) for i in range(12)]))
sets.append(("MENU_FONT",   [bg_layer(M + "title_font.png")]))

# ---- fonte bitmap (Visitor), ASCII 32..126 -------------------------------
FONT_PATH = os.path.join(SRC, "fonts", "visitor1.ttf")
FONT_SIZE = 20
ft = ImageFont.truetype(FONT_PATH, FONT_SIZE)
asc, desc = ft.getmetrics()
LINE_H = asc + desc
glyphs, advs = [], []
for c in range(32, 127):
    ch = chr(c)
    adv = max(1, int(round(ft.getlength(ch))))
    im = Image.new("L", (adv, LINE_H), 0)
    d = ImageDraw.Draw(im)
    d.fontmode = "1"
    d.text((0, 0), ch, font=ft, fill=255)
    rgba = Image.new("RGBA", (adv, LINE_H), (255, 255, 255, 0))
    rgba.putalpha(im)
    glyphs.append(rgba)
    advs.append(adv)
sets.append(("FONT", glyphs))

# ---- sprites.bin -----------------------------------------------------------
firsts, counts = [], []
total = 0
with open(os.path.join(DATA, "sprites.bin"), "wb") as f:
    f.write(b"KZSP")
    f.write(struct.pack(">I", sum(len(s[1]) for s in sets)))
    for name, ims in sets:
        firsts.append(total)
        counts.append(len(ims))
        for im in ims:
            a = np.asarray(im, dtype=np.uint8)           # H,W,4 (R,G,B,A)
            argb = np.empty_like(a)
            argb[..., 0] = a[..., 3]
            argb[..., 1] = a[..., 0]
            argb[..., 2] = a[..., 1]
            argb[..., 3] = a[..., 2]
            f.write(struct.pack(">HH", im.width, im.height))
            f.write(argb.tobytes())
            total += 1

with open(os.path.join(ROOT, "source", "gen_assets.h"), "w") as h:
    h.write("/* GERADO por tools/prep_assets.py -- nao editar */\n#ifndef GEN_ASSETS_H\n#define GEN_ASSETS_H\n\n")
    for i, (name, _) in enumerate(sets):
        h.write("#define SET_%s %d\n" % (name, i))
    h.write("#define SET_TOTAL %d\n#define SPRITE_TOTAL %d\n\n" % (len(sets), total))
    h.write("static const int SET_FIRST[SET_TOTAL] = {%s};\n" % ",".join(map(str, firsts)))
    h.write("static const int SET_COUNT[SET_TOTAL] = {%s};\n\n" % ",".join(map(str, counts)))
    h.write("#define FONT_LINE_H %d\n" % LINE_H)
    h.write("static const unsigned char FONT_ADV[95] = {%s};\n\n#endif\n" % ",".join(map(str, advs)))
print("sprites:", total, "em", len(sets), "conjuntos")


# ---- efeitos sonoros ---------------------------------------------------------
def to_pcm(path):
    return subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ar", "48000", "-ac", "1",
                           "-f", "s16be", "-"], stdout=subprocess.PIPE, check=True).stdout


sfx = []
for sub in ("Zero", "Enemy", "Bullet", "Menu"):
    for p in sorted(glob.glob(os.path.join(SRC, "sounds", sub, "*.wav"))):
        name = (sub + "/" + os.path.splitext(os.path.basename(p))[0]).lower()
        sfx.append((name, to_pcm(p)))
with open(os.path.join(DATA, "sfx.bin"), "wb") as f:
    f.write(b"KZSX")
    f.write(struct.pack(">I", len(sfx)))
    for name, pcm in sfx:
        nb = name.encode()
        f.write(struct.pack(">B", len(nb)) + nb)
        f.write(struct.pack(">I", len(pcm) // 2))
        f.write(pcm)
print("sfx:", len(sfx), "arquivos,", sum(len(p) for _, p in sfx) // 1024, "KB")

# ---- musicas ---------------------------------------------------------------
for p in sorted(glob.glob(os.path.join(SRC, "sounds", "Song", "*.wav"))):
    out = os.path.join(DATA, "music", os.path.splitext(os.path.basename(p))[0] + ".ogg")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", p, "-ar", "48000", "-ac", "2",
                    "-c:a", "libvorbis", "-q:a", "1", out], check=True)
    print("musica:", os.path.basename(out), os.path.getsize(out) // 1024, "KB")

# ---- mapas -----------------------------------------------------------------
for p in sorted(glob.glob(os.path.join(SRC, "maps", "level_*.csv"))):
    txt = open(p, newline="").read().replace("\r\n", "\n").replace("\r", "\n")
    open(os.path.join(DATA, "maps", os.path.basename(p)), "w", newline="\n").write(txt)

# ---- icone -----------------------------------------------------------------
ic = load(os.path.join(IMG, "Menu/title.jpg")).convert("RGB")
ic = ic.resize((320, 176), Image.LANCZOS)
ic.save(os.path.join(ROOT, "pkgfiles", "ICON0.PNG"))
print("ok")
